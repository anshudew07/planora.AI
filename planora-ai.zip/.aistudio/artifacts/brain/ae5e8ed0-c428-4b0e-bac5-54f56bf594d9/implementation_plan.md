# PLANORA AI — Brand Logo & AI Assistant Rebrand

This update delivers a custom luxury brand launcher icon and logo featuring an **Elegant Golden Monogram 'P' with sparkling stars on deep navy**, while updating all interactive assistant surfaces from "Copilot" to **"Planora AI"** with default AI sparkles.

---

### User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions were selected and confirmed during Phase 1 clarification:

- **Confirmed Logo & Launcher Icon Style**: Elegant Golden Monogram 'P' with royal celebratory starburst accents centered on Deep Midnight Navy (`#0B132B`).
- **Confirmed AI Assistant Branding**: Replacing all "Copilot" references across headers, hero action buttons, chat bubbles, and modal sheets with **"Planora AI"** using the standard AI sparkle emblem (`Icons.Default.AutoAwesome`).

---

## 1. Overview & Core Changes

1. **Custom Adaptive App Icon & In-App Logo**:
   - Create a vector/drawable asset for the golden monogram 'P' emblem flanked by four-point sparkling stars.
   - Configure `res/drawable/ic_launcher_foreground.xml` and `res/drawable/ic_launcher_background.xml` (`#0B132B`).
   - Generate raster fallback mipmaps (`ic_launcher.png` and circular `ic_launcher_round.png`) across `mdpi`, `hdpi`, `xhdpi`, `xxhdpi`, `xxxhdpi`, cleaning up default `.webp` files.
   - Update in-app brand header in `TopHeaderBar.kt` with the official golden 'P' emblem.

2. **Rebrand "Copilot" to "Planora AI"**:
   - **Top Navigation Bar**: Change badge from `"Copilot"` to `"Planora AI"` with gold-violet styling.
   - **Dashboard Hero Card**: Change `"Ask Copilot"` button to `"Ask Planora AI"`.
   - **Assistant Modal Bottom Sheet**:
     - Header: Rebrand to `"Planora AI Assistant"`.
     - Chat messages: Display `"Planora AI"` as the responder.
     - Proposal cards: Rebrand to `"Planora AI Proposed Changes"`.
     - Action button: `"Apply Planora AI Changes"`.
     - Placeholder text: `"Ask Planora AI or request changes..."`.
   - **Event Architect & Design Studio**: Update copilot optimization action chips to `"Planora AI"`.

---

## 2. Visual Architecture & Layout Comparison

```
Current UI (Copilot)                 New UI (Planora AI)
┌───────────────────────────────┐    ┌───────────────────────────────┐
│ [✨] PLANORA AI    [Copilot]  │──> │ [👑 P] PLANORA AI [Planora AI]│
└───────────────────────────────┘    └───────────────────────────────┘
               │                                    │
               ▼                                    ▼
┌───────────────────────────────┐    ┌───────────────────────────────┐
│ Dashboard Hero:               │    │ Dashboard Hero:               │
│ [ ✨ Ask Copilot ]            │──> │ [ ✨ Ask Planora AI ]         │
└───────────────────────────────┘    └───────────────────────────────┘
               │                                    │
               ▼                                    ▼
┌───────────────────────────────┐    ┌───────────────────────────────┐
│ Bottom Sheet:                 │    │ Bottom Sheet:                 │
│ "PLANORA AI Copilot"          │──> │ "Planora AI Assistant"        │
└───────────────────────────────┘    └───────────────────────────────┘
```

---

## 3. Technical Execution Roadmap

1. **Phase 1: App Icon & Logo Asset Generation**:
   - Build custom adaptive launcher foreground (`res/drawable/ic_launcher_foreground.xml`) featuring golden royal 'P' monogram and dual celestial starbursts.
   - Set launcher background (`res/drawable/ic_launcher_background.xml`) to `#0B132B`.
   - Provide standard raster mipmaps and circular masks for all screen densities.
2. **Phase 2: In-App Logo & Header Updates**:
   - Update `TopHeaderBar.kt` with the golden 'P' brand crest and replace `"Copilot"` pill button with `"Planora AI"`.
3. **Phase 3: Screen-by-Screen AI Rebranding**:
   - `DashboardScreen.kt`: Replace `"Ask Copilot"` button with `"Ask Planora AI"`.
   - `CopilotModalBottomSheet.kt`: Rebrand header, chat bubbles, proposal cards, and input hint to `"Planora AI"`.
   - `ArchitectScreen.kt` & `DesignStudioScreen.kt`: Update contextual action buttons.
4. **Phase 4: Verification & Build**:
   - Run compilation and tests to ensure clean builds.
