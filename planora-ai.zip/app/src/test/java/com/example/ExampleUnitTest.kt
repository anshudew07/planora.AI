package com.example

import com.example.data.DefaultEventRepository
import com.example.model.BudgetItem
import com.example.model.BudgetCategory
import com.example.util.CurrencyUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testCurrencyFormatting() {
        val inrFormatted = CurrencyUtils.formatInr(800000.0)
        assertEquals("₹8,00,000", inrFormatted)

        val inrSmall = CurrencyUtils.formatInr(25000.0)
        assertEquals("₹25,000", inrSmall)

        val shortLakh = CurrencyUtils.formatInrShort(800000.0)
        assertTrue(shortLakh.contains("8") && shortLakh.contains("Lakh"))

        val shortCr = CurrencyUtils.formatInrShort(15000000.0)
        assertTrue(shortCr.contains("1.5") && shortCr.contains("Cr"))
    }

    @Test
    fun testBudgetMathematicalValidation() {
        val items = listOf(
            BudgetItem("1", BudgetCategory.VENUE, allocatedAmount = 200000.0, actualSpent = 180000.0),
            BudgetItem("2", BudgetCategory.CATERING, allocatedAmount = 300000.0, actualSpent = 150000.0),
            BudgetItem("3", BudgetCategory.DECORATION, allocatedAmount = 100000.0, actualSpent = 80000.0)
        )

        val totalAllocated = CurrencyUtils.calculateTotalAllocated(items)
        assertEquals(600000.0, totalAllocated, 0.01)

        val totalSpent = CurrencyUtils.calculateTotalSpent(items)
        assertEquals(410000.0, totalSpent, 0.01)

        val remaining = CurrencyUtils.calculateRemainingBalance(600000.0, totalSpent)
        assertEquals(190000.0, remaining, 0.01)

        val utilization = CurrencyUtils.calculateUtilizationPercentage(600000.0, totalSpent)
        assertTrue(utilization in 68.0f..69.0f)

        assertFalse(CurrencyUtils.isOverBudget(600000.0, totalSpent))
        assertTrue(CurrencyUtils.isOverBudget(400000.0, totalSpent))
    }

    @Test
    fun testPreloadedRaipurWeddingScenario() {
        val raipurEvent = DefaultEventRepository.sampleRaipurWedding

        assertEquals("Ananya & Rohan's Royal Reception", raipurEvent.title)
        assertEquals(300, raipurEvent.guestCount)
        assertEquals(800000.0, raipurEvent.totalBudget, 0.01)

        val sumAllocated = raipurEvent.budgetItems.sumOf { it.allocatedAmount }
        assertEquals(800000.0, sumAllocated, 0.01)

        assertTrue(raipurEvent.tasks.isNotEmpty())
        assertTrue(raipurEvent.vendors.isNotEmpty())
        assertTrue(raipurEvent.guests.isNotEmpty())
        assertTrue(raipurEvent.risks.isNotEmpty())
    }
}
