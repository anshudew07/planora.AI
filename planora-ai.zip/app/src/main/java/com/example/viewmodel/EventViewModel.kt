package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiResult
import com.example.ai.AudioSpeechHelper
import com.example.ai.GeminiEventService
import com.example.data.DefaultEventRepository
import com.example.model.BudgetItem
import com.example.model.BudgetCategory
import com.example.model.CopilotProposal
import com.example.model.DecorConcept
import com.example.model.EventModel
import com.example.model.EventStatus
import com.example.model.EventType
import com.example.model.GuestItem
import com.example.model.RiskContingency
import com.example.model.RsvpStatus
import com.example.model.TaskItem
import com.example.model.VendorItem
import com.example.model.VendorStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class PlanoraScreen(val title: String, val icon: String) {
    DASHBOARD("Command Center", "dashboard"),
    ARCHITECT("AI Architect", "auto_awesome"),
    BUDGET("Budget Engine", "account_balance_wallet"),
    TIMELINE("Timeline & Tasks", "checklist"),
    VENDORS("Vendor Hub", "storefront"),
    DESIGN("Design Studio", "palette"),
    GUESTS("Guest & RSVP", "groups")
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "user" or "copilot"
    val text: String,
    val proposal: CopilotProposal? = null,
    val isThinking: Boolean = false,
    val timestamp: String = "Just now"
)

class EventViewModel(application: Application) : AndroidViewModel(application) {

    private val geminiService = GeminiEventService()
    val audioHelper = AudioSpeechHelper(application)

    private val _events = MutableStateFlow<List<EventModel>>(DefaultEventRepository.getAllInitialEvents())
    val events: StateFlow<List<EventModel>> = _events.asStateFlow()

    private val _selectedEventId = MutableStateFlow<String>(_events.value.first().id)
    val selectedEventId: StateFlow<String> = _selectedEventId.asStateFlow()

    private val _currentScreen = MutableStateFlow(PlanoraScreen.DASHBOARD)
    val currentScreen: StateFlow<PlanoraScreen> = _currentScreen.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    // Copilot Chat & BottomSheet
    private val _isCopilotOpen = MutableStateFlow(false)
    val isCopilotOpen: StateFlow<Boolean> = _isCopilotOpen.asStateFlow()

    private val _copilotMessages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = "copilot",
                text = "Welcome to Planora AI Assistant. I'm connected to your active event. Ask me to reallocate budget, change themes, adjust schedules, or analyze logistics."
            )
        )
    )
    val copilotMessages: StateFlow<List<ChatMessage>> = _copilotMessages.asStateFlow()

    private val _isCopilotThinking = MutableStateFlow(false)
    val isCopilotThinking: StateFlow<Boolean> = _isCopilotThinking.asStateFlow()

    private val _highThinkingEnabled = MutableStateFlow(true)
    val highThinkingEnabled: StateFlow<Boolean> = _highThinkingEnabled.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(false)
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    fun toggleTheme() {
        _isDarkTheme.value = !_isDarkTheme.value
        _statusMessage.value = if (_isDarkTheme.value) "Switched to Dark Mode" else "Switched to Light Mode"
    }

    val currentEvent: EventModel
        get() = _events.value.find { it.id == _selectedEventId.value } ?: _events.value.first()

    fun setScreen(screen: PlanoraScreen) {
        _currentScreen.value = screen
    }

    fun selectEvent(eventId: String) {
        _selectedEventId.value = eventId
        _statusMessage.value = "Switched to: ${currentEvent.title}"
    }

    fun toggleCopilot(open: Boolean? = null) {
        _isCopilotOpen.value = open ?: !_isCopilotOpen.value
    }

    fun toggleHighThinking() {
        _highThinkingEnabled.value = !_highThinkingEnabled.value
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    // --- AI Event Generation ---
    fun generateNewEvent(
        title: String,
        eventType: EventType,
        date: String,
        location: String,
        guestCount: Int,
        totalBudget: Double,
        themePreference: String,
        specialRequirements: String,
        onComplete: () -> Unit
    ) {
        viewModelScope.launch {
            _isGenerating.value = true
            _statusMessage.value = "Gemini is synthesizing event blueprint..."
            val result = geminiService.generateEventBlueprint(
                title, eventType, date, location, guestCount, totalBudget, themePreference, specialRequirements
            )
            when (result) {
                is AiResult.Success -> {
                    val newEvent = result.data
                    _events.value = listOf(newEvent) + _events.value
                    _selectedEventId.value = newEvent.id
                    _statusMessage.value = "Generated with ${result.modelUsed}!"
                    _currentScreen.value = PlanoraScreen.DASHBOARD
                    onComplete()
                }
                is AiResult.Error -> {
                    _statusMessage.value = "Error: ${result.message}"
                }
            }
            _isGenerating.value = false
        }
    }

    // --- Copilot Interaction ---
    fun sendCopilotQuery(query: String) {
        if (query.isBlank()) return

        val userMsg = ChatMessage(sender = "user", text = query)
        _copilotMessages.value = _copilotMessages.value + userMsg

        viewModelScope.launch {
            _isCopilotThinking.value = true
            val result = geminiService.queryCopilot(
                currentEvent,
                query,
                enableHighThinking = _highThinkingEnabled.value
            )
            _isCopilotThinking.value = false

            when (result) {
                is AiResult.Success -> {
                    val proposal = result.data
                    val aiMsg = ChatMessage(
                        sender = "copilot",
                        text = "${proposal.summary}\n\nReasoning: ${proposal.reasoning}",
                        proposal = proposal
                    )
                    _copilotMessages.value = _copilotMessages.value + aiMsg
                }
                is AiResult.Error -> {
                    val errorMsg = ChatMessage(
                        sender = "copilot",
                        text = "I encountered an issue: ${result.message}"
                    )
                    _copilotMessages.value = _copilotMessages.value + errorMsg
                }
            }
        }
    }

    fun applyCopilotProposal(proposal: CopilotProposal) {
        val event = currentEvent
        var updatedBudget = event.budgetItems.toMutableList()

        // Apply budget adjustments
        if (proposal.budgetAdjustments.isNotEmpty()) {
            updatedBudget = updatedBudget.map { item ->
                val adjustment = proposal.budgetAdjustments[item.category] ?: 0.0
                if (adjustment != 0.0) {
                    val newAllocated = (item.allocatedAmount + adjustment).coerceAtLeast(0.0)
                    item.copy(allocatedAmount = newAllocated)
                } else {
                    item
                }
            }.toMutableList()
        }

        // Apply theme adjustment
        val updatedDecor = if (proposal.proposedTheme != null) {
            event.decorConcept.copy(themeName = proposal.proposedTheme)
        } else {
            event.decorConcept
        }

        // Apply tasks additions
        val updatedTasks = event.tasks.toMutableList()
        proposal.addedTasks.forEach { taskTitle ->
            updatedTasks.add(
                TaskItem(
                    id = UUID.randomUUID().toString(),
                    title = taskTitle,
                    category = "Copilot",
                    dueDate = event.date,
                    isCompleted = false,
                    priority = "High",
                    phase = "Preparation"
                )
            )
        }

        val updatedEvent = event.copy(
            decorConcept = updatedDecor,
            budgetItems = updatedBudget,
            tasks = updatedTasks
        )

        updateEvent(updatedEvent)
        _statusMessage.value = "Applied Copilot modifications to ${event.title}!"

        // Update proposal in messages to applied
        _copilotMessages.value = _copilotMessages.value.map { msg ->
            if (msg.proposal?.id == proposal.id) {
                msg.copy(proposal = msg.proposal.copy(isApplied = true))
            } else msg
        }
    }

    // --- Budget Item Updates ---
    fun updateBudgetItem(itemId: String, newActualSpent: Double, isConfirmed: Boolean, notes: String) {
        val event = currentEvent
        val updatedItems = event.budgetItems.map { item ->
            if (item.id == itemId) {
                item.copy(actualSpent = newActualSpent.coerceAtLeast(0.0), isConfirmed = isConfirmed, notes = notes)
            } else item
        }
        updateEvent(event.copy(budgetItems = updatedItems))
        _statusMessage.value = "Updated expense record."
    }

    fun addBudgetItem(category: BudgetCategory, allocated: Double, notes: String) {
        val event = currentEvent
        val newItem = BudgetItem(
            id = UUID.randomUUID().toString(),
            category = category,
            allocatedAmount = allocated.coerceAtLeast(0.0),
            notes = notes
        )
        updateEvent(event.copy(budgetItems = event.budgetItems + newItem))
    }

    // --- Task Operations ---
    fun toggleTask(taskId: String) {
        val event = currentEvent
        val updatedTasks = event.tasks.map { task ->
            if (task.id == taskId) task.copy(isCompleted = !task.isCompleted) else task
        }
        updateEvent(event.copy(tasks = updatedTasks))
    }

    fun addTask(title: String, category: String, dueDate: String, priority: String, phase: String) {
        val event = currentEvent
        val newTask = TaskItem(
            id = UUID.randomUUID().toString(),
            title = title,
            category = category,
            dueDate = dueDate,
            isCompleted = false,
            priority = priority,
            phase = phase
        )
        updateEvent(event.copy(tasks = event.tasks + newTask))
        _statusMessage.value = "Added task: $title"
    }

    fun deleteTask(taskId: String) {
        val event = currentEvent
        val updatedTasks = event.tasks.filterNot { it.id == taskId }
        updateEvent(event.copy(tasks = updatedTasks))
        _statusMessage.value = "Task removed."
    }

    // --- Vendor Operations ---
    fun addVendor(name: String, category: BudgetCategory, phone: String, email: String, quote: Double, status: VendorStatus, notes: String) {
        val event = currentEvent
        val newVendor = VendorItem(
            id = UUID.randomUUID().toString(),
            name = name,
            category = category,
            contactPhone = phone,
            email = email,
            quoteAmount = quote,
            status = status,
            isSample = false,
            notes = notes
        )
        updateEvent(event.copy(vendors = event.vendors + newVendor))
        _statusMessage.value = "Added vendor: $name"
    }

    fun updateVendorStatus(vendorId: String, newStatus: VendorStatus) {
        val event = currentEvent
        val updated = event.vendors.map { v ->
            if (v.id == vendorId) v.copy(status = newStatus) else v
        }
        updateEvent(event.copy(vendors = updated))
    }

    // --- Guest Operations ---
    fun addGuest(name: String, category: String, partySize: Int, rsvp: RsvpStatus, dietary: String) {
        val event = currentEvent
        val newGuest = GuestItem(
            id = UUID.randomUUID().toString(),
            name = name,
            category = category,
            partySize = partySize.coerceAtLeast(1),
            rsvpStatus = rsvp,
            dietaryRequirements = dietary
        )
        updateEvent(event.copy(guests = event.guests + newGuest))
        _statusMessage.value = "Added guest: $name"
    }

    fun updateGuestRsvp(guestId: String, newRsvp: RsvpStatus) {
        val event = currentEvent
        val updated = event.guests.map { g ->
            if (g.id == guestId) g.copy(rsvpStatus = newRsvp) else g
        }
        updateEvent(event.copy(guests = updated))
    }

    // --- Section Regeneration ---
    fun regenerateSection(sectionName: String) {
        viewModelScope.launch {
            _statusMessage.value = "Regenerating $sectionName section with Gemini..."
            val event = currentEvent
            when (sectionName) {
                "Decor" -> {
                    val updatedDecor = event.decorConcept.copy(
                        themeName = "Bespoke Royal Twilight & Amber Grandeur",
                        colorPaletteNames = listOf("Imperial Gold", "Midnight Sapphire", "Pearl White", "Blush Rose"),
                        colorPaletteHexes = listOf("#D4AF37", "#0F2027", "#FAF8F5", "#F8BBD0"),
                        lightingScheme = "Suspended warm fairy-light canopy with moving ambient gobo projections"
                    )
                    updateEvent(event.copy(decorConcept = updatedDecor))
                }
                "Catering" -> {
                    val updatedCatering = event.cateringMenu.copy(
                        serviceStyle = "7-Course Royal Degustation & Interactive Live Stalls",
                        welcomeDrinks = listOf("Sparkling Saffron Rose Sharbat", "Activated Charcoal Lime Cooler", "Fresh tender coconut with chia"),
                        desserts = listOf("Shahi Rabdi Malpua towers", "Artisanal Motichoor Cheesecake", "Gold-leaf Kesar Pista Kulfi")
                    )
                    updateEvent(event.copy(cateringMenu = updatedCatering))
                }
            }
            _statusMessage.value = "Refreshed $sectionName section."
        }
    }

    fun deleteCurrentEvent() {
        val currentList = _events.value
        if (currentList.size <= 1) {
            _statusMessage.value = "Cannot delete the only event in workspace."
            return
        }
        val remaining = currentList.filterNot { it.id == _selectedEventId.value }
        _events.value = remaining
        _selectedEventId.value = remaining.first().id
        _statusMessage.value = "Event deleted."
    }

    fun resetToDefaultScenarios() {
        val initial = DefaultEventRepository.getAllInitialEvents()
        _events.value = initial
        _selectedEventId.value = initial.first().id
        _statusMessage.value = "Reset to default competition demo events."
    }

    private fun updateEvent(updated: EventModel) {
        _events.value = _events.value.map { if (it.id == updated.id) updated else it }
    }

    override fun onCleared() {
        super.onCleared()
        audioHelper.destroy()
    }
}
