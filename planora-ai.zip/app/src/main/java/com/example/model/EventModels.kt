package com.example.model

enum class EventType(val label: String) {
    WEDDING("Wedding Reception"),
    CORPORATE("Corporate Gala"),
    ANNIVERSARY("Milestone Anniversary"),
    BIRTHDAY("Birthday Celebration"),
    CULTURAL("Cultural Festival"),
    CUSTOM("Custom Celebration")
}

enum class EventStatus(val label: String) {
    PLANNING("Planning in Progress"),
    CONFIRMED("Confirmed"),
    COMPLETED("Completed")
}

enum class BudgetCategory(val displayName: String, val iconName: String) {
    VENUE("Venue & Infrastructure", "apartment"),
    CATERING("Catering & Beverages", "restaurant"),
    DECORATION("Decor & Florals", "palette"),
    PHOTOGRAPHY("Photo & Videography", "photo_camera"),
    ENTERTAINMENT("Music & Entertainment", "music_note"),
    TRANSPORTATION("Logistics & Transport", "directions_car"),
    ACCOMMODATION("Guest Accommodation", "hotel"),
    MISCELLANEOUS("Contingency & Misc", "receipt_long")
}

data class BudgetItem(
    val id: String,
    val category: BudgetCategory,
    val allocatedAmount: Double,
    val actualSpent: Double = 0.0,
    val isConfirmed: Boolean = false,
    val notes: String = ""
)

data class TaskItem(
    val id: String,
    val title: String,
    val category: String,
    val dueDate: String,
    val isCompleted: Boolean = false,
    val priority: String = "Medium", // High, Medium, Low
    val phase: String = "Preparation" // Preparation, 1 Month Before, Event Week, Event Day
)

enum class VendorStatus(val label: String) {
    INQUIRED("Inquiry Sent"),
    QUOTED("Quotation Received"),
    BOOKED("Contract Booked"),
    PAID("Fully Paid")
}

data class VendorItem(
    val id: String,
    val name: String,
    val category: BudgetCategory,
    val contactPhone: String,
    val email: String,
    val quoteAmount: Double,
    val status: VendorStatus,
    val isSample: Boolean = true,
    val notes: String = ""
)

enum class RsvpStatus(val label: String) {
    CONFIRMED("Confirmed"),
    PENDING("Awaiting RSVP"),
    DECLINED("Declined")
}

data class GuestItem(
    val id: String,
    val name: String,
    val category: String, // Family, VIP, Friends, Corporate
    val rsvpStatus: RsvpStatus,
    val partySize: Int = 1,
    val dietaryRequirements: String = "None"
)

data class EventConcept(
    val title: String,
    val tagline: String,
    val overview: String,
    val atmosphere: String,
    val dressCode: String,
    val highlights: List<String>
)

data class VenueRequirements(
    val spaceType: String,
    val capacityRequired: Int,
    val recommendedLayout: String,
    val audioVisualNeeds: String,
    val parkingCapacity: String,
    val locationAdvice: String
)

data class CateringMenu(
    val serviceStyle: String,
    val cuisineTypes: List<String>,
    val welcomeDrinks: List<String>,
    val appetizers: List<String>,
    val mainCourses: List<String>,
    val desserts: List<String>,
    val dietaryCoverage: String
)

data class DecorConcept(
    val themeName: String,
    val colorPaletteNames: List<String>,
    val colorPaletteHexes: List<String>,
    val stageSetup: String,
    val entranceArch: String,
    val lightingScheme: String,
    val tableCenterpieces: String
)

data class RiskContingency(
    val id: String,
    val riskTitle: String,
    val impact: String,
    val mitigationPlan: String
)

data class CopilotProposal(
    val id: String,
    val summary: String,
    val reasoning: String,
    val proposedTheme: String? = null,
    val budgetAdjustments: Map<BudgetCategory, Double> = emptyMap(),
    val addedTasks: List<String> = emptyList(),
    val isApplied: Boolean = false
)

data class EventModel(
    val id: String,
    val title: String,
    val eventType: EventType,
    val date: String,
    val location: String,
    val guestCount: Int,
    val totalBudget: Double,
    val themePreference: String,
    val specialRequirements: String,
    val status: EventStatus = EventStatus.PLANNING,
    // Blueprint sections
    val concept: EventConcept,
    val venueRequirements: VenueRequirements,
    val cateringMenu: CateringMenu,
    val decorConcept: DecorConcept,
    val budgetItems: List<BudgetItem>,
    val tasks: List<TaskItem>,
    val vendors: List<VendorItem>,
    val guests: List<GuestItem>,
    val risks: List<RiskContingency>,
    val pendingProposal: CopilotProposal? = null
)
