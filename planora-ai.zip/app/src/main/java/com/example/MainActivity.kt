package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.BottomNavBar
import com.example.ui.components.CopilotModalBottomSheet
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.ArchitectScreen
import com.example.ui.screens.BudgetScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.DesignStudioScreen
import com.example.ui.screens.GuestScreen
import com.example.ui.screens.TimelineScreen
import com.example.ui.screens.VendorScreen
import com.example.ui.theme.PlanoraAiTheme
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraViolet
import com.example.viewmodel.EventViewModel
import com.example.viewmodel.PlanoraScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: EventViewModel = viewModel()
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            PlanoraAiTheme(darkTheme = isDarkTheme) {
                PlanoraApp(viewModel)
            }
        }
    }
}

@Composable
fun PlanoraApp(viewModel: EventViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // Intercept back button to return to Dashboard if in another tab
    BackHandler(enabled = currentScreen != PlanoraScreen.DASHBOARD) {
        viewModel.setScreen(PlanoraScreen.DASHBOARD)
    }

    LaunchedEffect(statusMessage) {
        statusMessage?.let { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
            viewModel.clearStatusMessage()
        }
    }

    Scaffold(
        topBar = {
            TopHeaderBar(viewModel = viewModel)
        },
        bottomBar = {
            BottomNavBar(
                currentScreen = currentScreen,
                onSelectScreen = { viewModel.setScreen(it) }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.toggleCopilot(true) },
                containerColor = PlanoraViolet,
                contentColor = Color.White,
                shape = CircleShape,
                modifier = Modifier
                    .padding(bottom = 4.dp)
                    .testTag("floating_ai_action_btn")
            ) {
                Icon(
                    painter = painterResource(id = R.drawable.ic_ai_sparkle),
                    contentDescription = "Planora AI Assistant",
                    tint = Color.Unspecified,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        snackbarHost = {
            SnackbarHost(hostState = snackbarHostState)
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    PlanoraScreen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    PlanoraScreen.ARCHITECT -> ArchitectScreen(viewModel = viewModel)
                    PlanoraScreen.BUDGET -> BudgetScreen(viewModel = viewModel)
                    PlanoraScreen.TIMELINE -> TimelineScreen(viewModel = viewModel)
                    PlanoraScreen.VENDORS -> VendorScreen(viewModel = viewModel)
                    PlanoraScreen.DESIGN -> DesignStudioScreen(viewModel = viewModel)
                    PlanoraScreen.GUESTS -> GuestScreen(viewModel = viewModel)
                }
            }

            // Embedded AI Planning Copilot Bottom Sheet
            CopilotModalBottomSheet(viewModel = viewModel)
        }
    }
}
