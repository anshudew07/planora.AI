package com.example.util

import com.example.model.BudgetItem
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

object CurrencyUtils {

    /**
     * Formats amount according to Indian numbering system (e.g., 800000 -> "₹8,00,000")
     */
    fun formatInr(amount: Double): String {
        val isNegative = amount < 0
        val absAmount = abs(amount).roundToInt().toString()

        val formattedNumber = if (absAmount.length <= 3) {
            absAmount
        } else {
            val lastThree = absAmount.takeLast(3)
            val remaining = absAmount.dropLast(3)
            val groups = mutableListOf<String>()
            var temp = remaining
            while (temp.length > 2) {
                groups.add(0, temp.takeLast(2))
                temp = temp.dropLast(2)
            }
            if (temp.isNotEmpty()) {
                groups.add(0, temp)
            }
            groups.joinToString(",") + "," + lastThree
        }

        val prefix = if (isNegative) "-₹" else "₹"
        return "$prefix$formattedNumber"
    }

    /**
     * Formats amount into concise Indian Lakh / Crore format
     * e.g., 800000.0 -> "₹8.0 Lakh"
     *       15000000.0 -> "₹1.50 Cr"
     *       45000.0 -> "₹45 K"
     */
    fun formatInrShort(amount: Double): String {
        val isNegative = amount < 0
        val absVal = abs(amount)
        val prefix = if (isNegative) "-₹" else "₹"

        val df = DecimalFormat("#,##0.0#", DecimalFormatSymbols(Locale.US))

        return when {
            absVal >= 10_000_000.0 -> {
                val cr = absVal / 10_000_000.0
                "$prefix${df.format(cr)} Cr"
            }
            absVal >= 100_000.0 -> {
                val lakh = absVal / 100_000.0
                "$prefix${df.format(lakh)} Lakh"
            }
            absVal >= 1_000.0 -> {
                val k = absVal / 1_000.0
                "$prefix${df.format(k)} K"
            }
            else -> formatInr(amount)
        }
    }

    /**
     * Comprehensive display: e.g. "₹8,00,000 (₹8.0 Lakh)"
     */
    fun formatInrWithShort(amount: Double): String {
        if (abs(amount) < 100_000.0) return formatInr(amount)
        return "${formatInr(amount)} (${formatInrShort(amount)})"
    }

    // --- Mathematical Validations in Application Code ---

    fun calculateTotalAllocated(items: List<BudgetItem>): Double {
        return items.sumOf { it.allocatedAmount }
    }

    fun calculateTotalSpent(items: List<BudgetItem>): Double {
        return items.sumOf { it.actualSpent }
    }

    fun calculateRemainingBalance(totalBudget: Double, spent: Double): Double {
        return (totalBudget - spent).coerceAtLeast(-999_999_999.0)
    }

    fun calculateUtilizationPercentage(totalBudget: Double, spent: Double): Float {
        if (totalBudget <= 0.0) return 0f
        return ((spent / totalBudget) * 100).toFloat().coerceIn(0f, 999f)
    }

    fun isOverBudget(totalBudget: Double, spent: Double): Boolean {
        return spent > totalBudget
    }

    /**
     * Validates that budget allocations do not violate physical constraints
     */
    fun validateBudget(totalBudget: Double, items: List<BudgetItem>): BudgetValidationResult {
        if (totalBudget <= 0.0) {
            return BudgetValidationResult.Invalid("Total budget must be greater than ₹0")
        }
        val allocatedSum = calculateTotalAllocated(items)
        if (allocatedSum > totalBudget) {
            val excess = allocatedSum - totalBudget
            return BudgetValidationResult.Warning(
                "Allocated budget exceeds total budget by ${formatInrShort(excess)}"
            )
        }
        return BudgetValidationResult.Valid
    }
}

sealed interface BudgetValidationResult {
    data object Valid : BudgetValidationResult
    data class Warning(val message: String) : BudgetValidationResult
    data class Invalid(val reason: String) : BudgetValidationResult
}
