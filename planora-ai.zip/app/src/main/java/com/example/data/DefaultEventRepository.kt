package com.example.data

import com.example.model.BudgetItem
import com.example.model.BudgetCategory
import com.example.model.CateringMenu
import com.example.model.DecorConcept
import com.example.model.EventConcept
import com.example.model.EventModel
import com.example.model.EventStatus
import com.example.model.EventType
import com.example.model.GuestItem
import com.example.model.RiskContingency
import com.example.model.RsvpStatus
import com.example.model.TaskItem
import com.example.model.VendorItem
import com.example.model.VendorStatus
import com.example.model.VenueRequirements

object DefaultEventRepository {

    val sampleRaipurWedding: EventModel = EventModel(
        id = "event_raipur_wedding",
        title = "Ananya & Rohan's Royal Reception",
        eventType = EventType.WEDDING,
        date = "18 Dec 2026",
        location = "VIP Road Banquet Lawns, Raipur, CG",
        guestCount = 300,
        totalBudget = 800000.0, // ₹8,00,000 (₹8 Lakh)
        themePreference = "Royal Rajputana Heritage & Modern Grandeur",
        specialRequirements = "Traditional Chhattisgarhi welcome, live shehnai & acoustic sufi, Jain catering counter.",
        status = EventStatus.PLANNING,
        concept = EventConcept(
            title = "Royal Heritage & Velvet Twilight",
            tagline = "A grand regal evening blending royal heritage with contemporary luxury.",
            overview = "Designed for 300 distinguished guests at Raipur's open-air banquet lawns. Featuring royal arches, warm amber illumination, and gourmet multi-cuisine feast.",
            atmosphere = "Opulent, warm, celebratory, and culturally resonant.",
            dressCode = "Traditional Indian Royal Formal / Sherwanis & Embroidered Lehengas",
            highlights = listOf(
                "Regal entry walkway flanked by brass diya lanterns & fresh marigold cascades",
                "Grand floral mandap stage with velvet backdrop & crystal chandelier accents",
                "Multi-state live culinary stalls: North Indian, Chhattisgarhi specialties, & Live Chaat",
                "Curated 360-degree guest photo-booth with vintage royal motifs"
            )
        ),
        venueRequirements = VenueRequirements(
            spaceType = "Open-Air Lawn + Covered Banquet Hall",
            capacityRequired = 350,
            recommendedLayout = "Central aisle with tiered round-table seating (10 pax/table) & elevated 32x20 ft stage",
            audioVisualNeeds = "Dual high-lumen LED walls (12x8 ft), line-array sound system, wireless lapel & handheld mics",
            parkingCapacity = "Valet parking for 120 cars + designated family drop-off zone",
            locationAdvice = "Ensure proximity to Raipur Airport corridor with clear signage from VIP Road junction."
        ),
        cateringMenu = CateringMenu(
            serviceStyle = "Grand Royal Buffet with Live Gourmet Counters",
            cuisineTypes = listOf("North Indian Mughlai", "Chhattisgarhi Delicacies", "Pan-Asian Live Wok", "Artisanal Dessert Bar"),
            welcomeDrinks = listOf("Kesariya Thandai", "Spiced Kokum Cooler", "Fresh tender coconut with mint sprig"),
            appetizers = listOf("Paneer Tikka Angara", "Dahi Ke Kebab", "Galouti Sliders", "Amritsari Fish Fingers", "Bhatti Murgh Tikka"),
            mainCourses = listOf("Dal Makhani Bukhara", "Paneer Lababdar", "Dehati Dum Aloo", "Chhattisgarhi Fara Counter", "Awadhi Murgh Biryani", "Mirch Ka Salan"),
            desserts = listOf("Hot Jalebi with Rabdi", "Gulab Jamun infused with cardamom", "Sizzling Brownie with Vanilla Cream", "Moong Dal Halwa"),
            dietaryCoverage = "Dedicated 100% vegetarian & Jain counter with separate prep galley."
        ),
        decorConcept = DecorConcept(
            themeName = "Royal Gold, Deep Maroon & Velvet Ivory",
            colorPaletteNames = listOf("Imperial Gold", "Royal Burgundy", "Warm Ivory", "Emerald Foliage"),
            colorPaletteHexes = listOf("#C59B27", "#800020", "#FAF8F5", "#2E7D32"),
            stageSetup = "Architectural Mughal arch frame layered with fresh tuberose (Rajnigandha) and warm backlit fabric.",
            entranceArch = "Grand 16-foot arched wooden gateway wrapped in fresh marigold garlands with royal dhol welcome.",
            lightingScheme = "Soft 2700K warm wash across lawns, fairy light canopy overhead, and accent uplights on trees.",
            tableCenterpieces = "Handcrafted brass Urli bowls with floating lotus blossoms and scented tea-lights."
        ),
        budgetItems = listOf(
            BudgetItem("b_venue", BudgetCategory.VENUE, allocatedAmount = 220000.0, actualSpent = 200000.0, isConfirmed = true, notes = "Lawn booking advance cleared"),
            BudgetItem("b_catering", BudgetCategory.CATERING, allocatedAmount = 280000.0, actualSpent = 150000.0, isConfirmed = false, notes = "Per plate @ ₹850 for 300 pax"),
            BudgetItem("b_decor", BudgetCategory.DECORATION, allocatedAmount = 130000.0, actualSpent = 60000.0, isConfirmed = false, notes = "Floral arch, stage, and table urns"),
            BudgetItem("b_photo", BudgetCategory.PHOTOGRAPHY, allocatedAmount = 70000.0, actualSpent = 35000.0, isConfirmed = true, notes = "Candid photographer + 4K cinematic film"),
            BudgetItem("b_entertainment", BudgetCategory.ENTERTAINMENT, allocatedAmount = 40000.0, actualSpent = 20000.0, isConfirmed = true, notes = "Live sufi trio & acoustic sound team"),
            BudgetItem("b_transport", BudgetCategory.TRANSPORTATION, allocatedAmount = 25000.0, actualSpent = 0.0, isConfirmed = false, notes = "Innova cabs for airport transfers"),
            BudgetItem("b_stay", BudgetCategory.ACCOMMODATION, allocatedAmount = 20000.0, actualSpent = 0.0, isConfirmed = false, notes = "VIP suites reserved near venue"),
            BudgetItem("b_misc", BudgetCategory.MISCELLANEOUS, allocatedAmount = 15000.0, actualSpent = 0.0, isConfirmed = false, notes = "Emergency contingency buffer")
        ),
        tasks = listOf(
            TaskItem("t1", "Finalize Banquet Lawn contract on VIP Road", "Venue", "01 Nov 2026", isCompleted = true, priority = "High", phase = "Preparation"),
            TaskItem("t2", "Review & taste catering menu selections with chef", "Catering", "15 Nov 2026", isCompleted = true, priority = "High", phase = "Preparation"),
            TaskItem("t3", "Approve 3D stage and lighting render from decorator", "Decor", "25 Nov 2026", isCompleted = false, priority = "Medium", phase = "1 Month Before"),
            TaskItem("t4", "Dispatch physical and digital royal RSVP invites", "Guests", "01 Dec 2026", isCompleted = true, priority = "High", phase = "1 Month Before"),
            TaskItem("t5", "Confirm airport pickups for outstation guests", "Logistics", "10 Dec 2026", isCompleted = false, priority = "Medium", phase = "Event Week"),
            TaskItem("t6", "Soundcheck with live Sufi band & AV technicians", "Entertainment", "17 Dec 2026", isCompleted = false, priority = "High", phase = "Event Week"),
            TaskItem("t7", "Bride & Groom grand entry coordination with dholak team", "Coordination", "18 Dec 2026", isCompleted = false, priority = "High", phase = "Event Day")
        ),
        vendors = listOf(
            VendorItem("v1", "Mayfair Lawns & Banquets", BudgetCategory.VENUE, "+91 98271 44001", "reservations@mayfairlawns.example.com", quoteAmount = 220000.0, status = VendorStatus.BOOKED, isSample = true, notes = "Signed 12hr slot with generator backup"),
            VendorItem("v2", "Annapurna Royal Caterers", BudgetCategory.CATERING, "+91 94252 88200", "catering@annapurna.example.com", quoteAmount = 280000.0, status = VendorStatus.QUOTED, isSample = true, notes = "Sample tasting approved, final headcount due 10 Dec"),
            VendorItem("v3", "Utsav Floral & Stage Decor", BudgetCategory.DECORATION, "+91 77140 19000", "utsav.decor@example.com", quoteAmount = 130000.0, status = VendorStatus.INQUIRED, isSample = true, notes = "Quote includes real rajnigandha & carnations"),
            VendorItem("v4", "Drishti Cine Studios", BudgetCategory.PHOTOGRAPHY, "+91 97555 12345", "contact@drishtistudios.example.com", quoteAmount = 70000.0, status = VendorStatus.BOOKED, isSample = true, notes = "Includes 2 candid cams, 1 drone operator, teaser reel")
        ),
        guests = listOf(
            GuestItem("g1", "Mr. & Mrs. Sharma (Groom's Parents)", "Family", RsvpStatus.CONFIRMED, partySize = 4, dietaryRequirements = "Vegetarian"),
            GuestItem("g2", "Verma Family (Bride's Grandparents)", "Family", RsvpStatus.CONFIRMED, partySize = 6, dietaryRequirements = "Jain (Strict)"),
            GuestItem("g3", "Dr. A. K. Patel (VIP Guest)", "VIP", RsvpStatus.CONFIRMED, partySize = 2, dietaryRequirements = "No Onion/Garlic"),
            GuestItem("g4", "Raipur Alumni Chapter", "Friends", RsvpStatus.PENDING, partySize = 12, dietaryRequirements = "Standard"),
            GuestItem("g5", "Corporate Partners Group", "Corporate", RsvpStatus.CONFIRMED, partySize = 8, dietaryRequirements = "Mixed")
        ),
        risks = listOf(
            RiskContingency("r1", "Winter evening chill & humidity on open lawn", "Moderate", "Contract 10 patio gas warmers and keep banquet hall foyer open for elderly guests."),
            RiskContingency("r2", "Overhead generator power trip during stage lighting peaks", "High", "Dedicated 125 kVA generator with automatic phase changeover switch installed on-site."),
            RiskContingency("r3", "Guest headcount surge over 300 pax", "Moderate", "Caterer instructed with standard 10% buffer food reserve (up to 330 guests).")
        )
    )

    val sampleCorporateGala: EventModel = EventModel(
        id = "event_corp_gala",
        title = "FutureSphere 2026 Tech Summit & Gala",
        eventType = EventType.CORPORATE,
        date = "15 Jan 2027",
        location = "Grand Ballroom, Whitefield, Bengaluru",
        guestCount = 150,
        totalBudget = 500000.0, // ₹5,00,000 (₹5 Lakh)
        themePreference = "Cyber Elegance & High-Tech Luminescence",
        specialRequirements = "Ultra-fast Wi-Fi, keynote podium with teleprompter, eco-friendly zero-plastic setup.",
        status = EventStatus.PLANNING,
        concept = EventConcept(
            title = "FutureSphere: Connect, Elevate, Inspire",
            tagline = "An executive tech forum celebrating breakthrough innovations.",
            overview = "Designed for 150 venture founders, enterprise CTOs, and tech innovators. Combines dynamic keynote presentations with an upscale evening networking gala.",
            atmosphere = "Futuristic, sleek, high-energy, and professional.",
            dressCode = "Smart Business Casual with Modern Edge",
            highlights = listOf(
                "Immersive 4K curved LED backdrop for keynote reveals",
                "Speed networking lounge with curated seating algorithm",
                "Cocktail masterclass & sustainable organic hors d'oeuvres",
                "Interactive tech showcase kiosks for ecosystem startups"
            )
        ),
        venueRequirements = VenueRequirements(
            spaceType = "5-Star Hotel Grand Ballroom",
            capacityRequired = 180,
            recommendedLayout = "Classroom seating for morning keynotes converting to lounge pods for gala",
            audioVisualNeeds = "Dual 4K Laser Projectors, directional audio pods, wireless translation gear",
            parkingCapacity = "Valet for 80 vehicles with EV charging bays",
            locationAdvice = "Within 15 minutes of tech corridor metro access."
        ),
        cateringMenu = CateringMenu(
            serviceStyle = "Plated Gourmet Tasting & Live Tapas Bar",
            cuisineTypes = listOf("Modern European", "Pan-Asian Robata", "Fusion Indian", "Artisan Gelato"),
            welcomeDrinks = listOf("Activated Charcoal Citrus Sparkler", "Lemongrass Iced Infusion", "Cold Brew Tonic"),
            appetizers = listOf("Truffle Edamame Dumplings", "Smoked Salmon Crostini", "Paneer Mille-Feuille", "Korean Glazed Tofu Bites"),
            mainCourses = listOf("Wild Mushroom Risotto", "Herb Crusted Seabass", "Kashmiri Morel Rogan", "Sourdough Focaccia Assortment"),
            desserts = listOf("Belgian Chocolate Mousse Tart", "Yuzu Sorbet", "Baked Cheesecake bites"),
            dietaryCoverage = "Clear allergen markers for gluten-free, dairy-free, and vegan diets."
        ),
        decorConcept = DecorConcept(
            themeName = "Obsidian Black, Neon Cyan & Brushed Titanium",
            colorPaletteNames = listOf("Midnight Obsidian", "Electric Cyan", "Brushed Silver", "Deep Navy"),
            colorPaletteHexes = listOf("#111827", "#06B6D4", "#94A3B8", "#1E293B"),
            stageSetup = "Minimalist geometric stage with integrated neon perimeter glow and frosted glass podium.",
            entranceArch = "Illuminated neon infinity tunnel with corporate partner holographic logos.",
            lightingScheme = "Dynamic smart DMX beam lights timed to keynote transitions.",
            tableCenterpieces = "Minimalist geometric terrariums with wireless charging mats embedded in table hubs."
        ),
        budgetItems = listOf(
            BudgetItem("bc_venue", BudgetCategory.VENUE, allocatedAmount = 180000.0, actualSpent = 180000.0, isConfirmed = true, notes = "Includes ballroom & breakout suites"),
            BudgetItem("bc_catering", BudgetCategory.CATERING, allocatedAmount = 160000.0, actualSpent = 80000.0, isConfirmed = false, notes = "₹1,000/head for 150 pax"),
            BudgetItem("bc_decor", BudgetCategory.DECORATION, allocatedAmount = 60000.0, actualSpent = 30000.0, isConfirmed = false, notes = "Neon tunnel and stage branding"),
            BudgetItem("bc_photo", BudgetCategory.PHOTOGRAPHY, allocatedAmount = 40000.0, actualSpent = 20000.0, isConfirmed = true, notes = "Event videography & same-day social cuts"),
            BudgetItem("bc_entertainment", BudgetCategory.ENTERTAINMENT, allocatedAmount = 30000.0, actualSpent = 0.0, isConfirmed = false, notes = "Keynote MC and acoustic jazz trio"),
            BudgetItem("bc_transport", BudgetCategory.TRANSPORTATION, allocatedAmount = 15000.0, actualSpent = 0.0, isConfirmed = false, notes = "VIP shuttle from airport"),
            BudgetItem("bc_stay", BudgetCategory.ACCOMMODATION, allocatedAmount = 10000.0, actualSpent = 0.0, isConfirmed = false, notes = "Keynote speaker rooms"),
            BudgetItem("bc_misc", BudgetCategory.MISCELLANEOUS, allocatedAmount = 5000.0, actualSpent = 0.0, isConfirmed = false, notes = "Name badges & contingency")
        ),
        tasks = listOf(
            TaskItem("tc1", "Sign Ballroom agreement with IT Park Hotel", "Venue", "10 Dec 2026", isCompleted = true, priority = "High", phase = "Preparation"),
            TaskItem("tc2", "Finalize keynote speaker lineup & slide decks", "Content", "20 Dec 2026", isCompleted = true, priority = "High", phase = "Preparation"),
            TaskItem("tc3", "Setup attendee badge printing & QR check-in app", "Tech", "05 Jan 2027", isCompleted = false, priority = "Medium", phase = "Event Week"),
            TaskItem("tc4", "Technical rehearsal & wireless mic tests", "AV", "14 Jan 2027", isCompleted = false, priority = "High", phase = "Event Week")
        ),
        vendors = listOf(
            VendorItem("vc1", "The Grand Silicon Ballroom", BudgetCategory.VENUE, "+91 80 4455 6677", "events@siliconballroom.example.com", quoteAmount = 180000.0, status = VendorStatus.BOOKED, isSample = true),
            VendorItem("vc2", "Pulse Tech AV Solutions", BudgetCategory.ENTERTAINMENT, "+91 98450 11223", "av@pulseav.example.com", quoteAmount = 30000.0, status = VendorStatus.QUOTED, isSample = true)
        ),
        guests = listOf(
            GuestItem("gc1", "Kiran Mazumdar (Keynote Speaker)", "VIP", RsvpStatus.CONFIRMED, partySize = 2),
            GuestItem("gc2", "Arjun Narang (Sequoia Partner)", "VIP", RsvpStatus.CONFIRMED, partySize = 1),
            GuestItem("gc3", "Tech Founders Cohort (40 pax)", "Corporate", RsvpStatus.CONFIRMED, partySize = 40)
        ),
        risks = listOf(
            RiskContingency("rc1", "Keynote AV sync lag or slide clicker failure", "High", "Redundant HDMI switcher with duplicate mirrored MacBook on standby.")
        )
    )

    val sampleAnniversary: EventModel = EventModel(
        id = "event_anniversary",
        title = "Sunita & Rajesh's Silver Jubilee",
        eventType = EventType.ANNIVERSARY,
        date = "05 Feb 2027",
        location = "Lakeside Courtyard, Udaipur, Rajasthan",
        guestCount = 80,
        totalBudget = 200000.0, // ₹2,00,000 (₹2 Lakh)
        themePreference = "Romantic Lakeside Candlelight Reverie",
        specialRequirements = "Nostalgic slide show from 2002, acoustic violin duo, heritage Rajasthani thali.",
        status = EventStatus.PLANNING,
        concept = EventConcept(
            title = "25 Years of Grace & Love",
            tagline = "An intimate silver jubilee celebration under the starlit lakeside sky.",
            overview = "Honoring 25 years of cherished memories with 80 close family members and lifelong friends.",
            atmosphere = "Warm, sentimental, nostalgic, and romantic.",
            dressCode = "Silver & Pastel Indian Elegance",
            highlights = listOf(
                "Memory lane photo arch depicting milestones from 2002 to 2027",
                "Acoustic violin and sitar fusion performance during sunset",
                "Cake cutting with 25 silver sparklers"
            )
        ),
        venueRequirements = VenueRequirements(
            spaceType = "Boutique Heritage Courtyard by Lake Pichola",
            capacityRequired = 90,
            recommendedLayout = "Intimate banquet arrangement with fairy light canopy",
            audioVisualNeeds = "Short-throw projector for family nostalgia documentary",
            parkingCapacity = "20 cars",
            locationAdvice = "Lake boat transfer arranged for guests from main jetty."
        ),
        cateringMenu = CateringMenu(
            serviceStyle = "Royal Mewari Thali Service",
            cuisineTypes = listOf("Authentic Rajasthani Mewari", "Continental Lite"),
            welcomeDrinks = listOf("Rose Petal Sharbat", "Jaljeera Fizz"),
            appetizers = listOf("Pyaaz Kachori Bites", "Paneer Khurchan Roll", "Corn Cheese Croquettes"),
            mainCourses = listOf("Dal Baati Churma", "Gatta Curry", "Ker Sangri", "Missi Roti Assortment"),
            desserts = listOf("Malpua with Rabdi", "Kulfi Falooda"),
            dietaryCoverage = "Pure vegetarian menu."
        ),
        decorConcept = DecorConcept(
            themeName = "Silver Shimmer & Blush Rose",
            colorPaletteNames = listOf("Metallic Silver", "Blush Pink", "Warm Amber", "Ivory"),
            colorPaletteHexes = listOf("#C0C0C0", "#F8BBD0", "#FFB300", "#FAF8F5"),
            stageSetup = "Intimate wooden gazebos decorated with silver fairy curtains and pastel roses.",
            entranceArch = "Floral frame with silver fairy lights and vintage brass lanterns.",
            lightingScheme = "100+ scented glass tea-light candles floating on lakeside water bowls.",
            tableCenterpieces = "Crystal bud vases with fresh white lilies and blush roses."
        ),
        budgetItems = listOf(
            BudgetItem("ba_venue", BudgetCategory.VENUE, allocatedAmount = 70000.0, actualSpent = 70000.0, isConfirmed = true),
            BudgetItem("ba_catering", BudgetCategory.CATERING, allocatedAmount = 65000.0, actualSpent = 30000.0, isConfirmed = false),
            BudgetItem("ba_decor", BudgetCategory.DECORATION, allocatedAmount = 30000.0, actualSpent = 15000.0, isConfirmed = false),
            BudgetItem("ba_photo", BudgetCategory.PHOTOGRAPHY, allocatedAmount = 20000.0, actualSpent = 10000.0, isConfirmed = true),
            BudgetItem("ba_entertainment", BudgetCategory.ENTERTAINMENT, allocatedAmount = 10000.0, actualSpent = 5000.0, isConfirmed = true),
            BudgetItem("ba_misc", BudgetCategory.MISCELLANEOUS, allocatedAmount = 5000.0, actualSpent = 0.0, isConfirmed = false)
        ),
        tasks = listOf(
            TaskItem("ta1", "Reserve lakeside courtyard", "Venue", "15 Nov 2026", isCompleted = true, priority = "High"),
            TaskItem("ta2", "Compile 25-year family photo slideshow", "Media", "10 Jan 2027", isCompleted = true, priority = "Medium"),
            TaskItem("ta3", "Order silver anniversary tiered cake", "Bakery", "25 Jan 2027", isCompleted = false, priority = "High")
        ),
        vendors = listOf(
            VendorItem("va1", "Udaivilas Courtyard", BudgetCategory.VENUE, "+91 294 243 0000", "heritage@udaivilas.example.com", quoteAmount = 70000.0, status = VendorStatus.BOOKED, isSample = true)
        ),
        guests = listOf(
            GuestItem("ga1", "Immediate Family (22 pax)", "Family", RsvpStatus.CONFIRMED, partySize = 22),
            GuestItem("ga2", "College Friends Circle (18 pax)", "Friends", RsvpStatus.CONFIRMED, partySize = 18)
        ),
        risks = listOf(
            RiskContingency("ra1", "Lakeside evening breeze causing candle flicker", "Low", "Use hurricane glass chimneys for all candle displays.")
        )
    )

    fun getAllInitialEvents(): List<EventModel> {
        return listOf(sampleRaipurWedding, sampleCorporateGala, sampleAnniversary)
    }
}
