package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GuestItem
import com.example.model.RsvpStatus
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraCrimson
import com.example.ui.theme.PlanoraCrimsonBg
import com.example.ui.theme.PlanoraEmerald
import com.example.ui.theme.PlanoraEmeraldBg
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraGoldBg
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.viewmodel.EventViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuestScreen(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val event = viewModel.currentEvent
    var selectedFilter by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }

    val confirmedTotal = event.guests.filter { it.rsvpStatus == RsvpStatus.CONFIRMED }.sumOf { it.partySize }
    val pendingTotal = event.guests.filter { it.rsvpStatus == RsvpStatus.PENDING }.sumOf { it.partySize }
    val declinedTotal = event.guests.filter { it.rsvpStatus == RsvpStatus.DECLINED }.sumOf { it.partySize }

    val filteredGuests = when (selectedFilter) {
        "Confirmed" -> event.guests.filter { it.rsvpStatus == RsvpStatus.CONFIRMED }
        "Pending" -> event.guests.filter { it.rsvpStatus == RsvpStatus.PENDING }
        "Declined" -> event.guests.filter { it.rsvpStatus == RsvpStatus.DECLINED }
        else -> event.guests
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PlanoraViolet,
                contentColor = PlanoraIvory,
                shape = CircleShape,
                modifier = Modifier.testTag("add_guest_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Guest")
            }
        },
        containerColor = PlanoraIvory,
        modifier = modifier
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Header Stats
            Surface(
                color = PlanoraIvoryCard,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Guest Management & RSVP Hub",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    Text(
                        text = "Capacity: ${event.guestCount} Target Guests",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RsvpCounterCard("Confirmed", "$confirmedTotal", PlanoraEmerald, PlanoraEmeraldBg, Modifier.weight(1f))
                        RsvpCounterCard("Pending", "$pendingTotal", PlanoraGold, PlanoraGoldBg, Modifier.weight(1f))
                        RsvpCounterCard("Declined", "$declinedTotal", PlanoraCrimson, PlanoraCrimsonBg, Modifier.weight(1f))
                    }
                }
            }

            // Filters
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf("All", "Confirmed", "Pending", "Declined")
                items(filters) { f ->
                    FilterChip(
                        selected = selectedFilter == f,
                        onClick = { selectedFilter = f },
                        label = { Text(f, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PlanoraNavy,
                            selectedLabelColor = PlanoraIvory,
                            containerColor = PlanoraIvoryCard,
                            labelColor = PlanoraNavy
                        )
                    )
                }
            }

            // Guest list
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredGuests) { guest ->
                    GuestCard(
                        guest = guest,
                        onRsvpChange = { newRsvp ->
                            viewModel.updateGuestRsvp(guest.id, newRsvp)
                        }
                    )
                }

                item { Spacer(modifier = Modifier.height(70.dp)) }
            }
        }
    }

    if (showAddDialog) {
        AddGuestDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, category, size, rsvp, dietary ->
                viewModel.addGuest(name, category, size, rsvp, dietary)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun RsvpCounterCard(
    label: String,
    count: String,
    textColor: Color,
    bgColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = bgColor,
        shape = RoundedCornerShape(10.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = count, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = textColor)
            Text(text = label, fontSize = 10.sp, color = PlanoraNavy, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun GuestCard(
    guest: GuestItem,
    onRsvpChange: (RsvpStatus) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(PlanoraGoldBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = guest.name,
                            tint = PlanoraGold,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = guest.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = PlanoraIvoryMuted,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = guest.category,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PlanoraNavy,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Party size: ${guest.partySize}",
                                fontSize = 11.sp,
                                color = PlanoraTextSecondary
                            )
                        }
                    }
                }

                Surface(
                    color = when (guest.rsvpStatus) {
                        RsvpStatus.CONFIRMED -> PlanoraEmeraldBg
                        RsvpStatus.PENDING -> PlanoraGoldBg
                        RsvpStatus.DECLINED -> PlanoraCrimsonBg
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = guest.rsvpStatus.label,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (guest.rsvpStatus) {
                            RsvpStatus.CONFIRMED -> PlanoraEmerald
                            RsvpStatus.PENDING -> PlanoraGold
                            RsvpStatus.DECLINED -> PlanoraCrimson
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            if (guest.dietaryRequirements.isNotBlank() && guest.dietaryRequirements != "None") {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Dietary: ${guest.dietaryRequirements}",
                    fontSize = 11.sp,
                    color = PlanoraViolet,
                    fontWeight = FontWeight.Medium
                )
            }

            // Quick RSVP status toggle row
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                RsvpStatus.entries.forEach { status ->
                    val isCurrent = guest.rsvpStatus == status
                    Surface(
                        color = if (isCurrent) PlanoraNavy else PlanoraIvoryMuted,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onRsvpChange(status) }
                    ) {
                        Text(
                            text = status.name.take(4),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCurrent) PlanoraIvory else PlanoraNavy,
                            modifier = Modifier.padding(vertical = 4.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddGuestDialog(
    onDismiss: () -> Unit,
    onAdd: (String, String, Int, RsvpStatus, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Family") }
    var partySizeStr by remember { mutableStateOf("2") }
    var rsvp by remember { mutableStateOf(RsvpStatus.CONFIRMED) }
    var dietary by remember { mutableStateOf("Vegetarian") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Guest", fontWeight = FontWeight.Bold, color = PlanoraNavy) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Guest / Family Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Group (Family, VIP, Friends, Corporate)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = partySizeStr,
                    onValueChange = { partySizeStr = it },
                    label = { Text("Party Size (Seats)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = dietary,
                    onValueChange = { dietary = it },
                    label = { Text("Dietary Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val size = partySizeStr.toIntOrNull() ?: 1
                    if (name.isNotBlank()) onAdd(name, category, size, rsvp, dietary)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet),
                enabled = name.isNotBlank()
            ) {
                Text("Add Guest")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
