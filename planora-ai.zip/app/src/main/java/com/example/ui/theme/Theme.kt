package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = PlanoraNavy,
    onPrimary = PlanoraIvory,
    primaryContainer = PlanoraNavySurface,
    onPrimaryContainer = PlanoraIvory,
    secondary = PlanoraViolet,
    onSecondary = PlanoraIvoryCard,
    secondaryContainer = PlanoraVioletBg,
    onSecondaryContainer = PlanoraNavy,
    tertiary = PlanoraGold,
    onTertiary = PlanoraNavy,
    tertiaryContainer = PlanoraGoldBg,
    onTertiaryContainer = PlanoraNavy,
    background = PlanoraIvory,
    onBackground = PlanoraTextPrimary,
    surface = PlanoraIvoryCard,
    onSurface = PlanoraTextPrimary,
    surfaceVariant = PlanoraIvoryMuted,
    onSurfaceVariant = PlanoraTextSecondary,
    outline = PlanoraBorder,
    error = PlanoraCrimson,
    onError = PlanoraIvoryCard,
    errorContainer = PlanoraCrimsonBg,
    onErrorContainer = PlanoraCrimson
)

private val DarkColorScheme = darkColorScheme(
    primary = PlanoraVioletLight,
    onPrimary = PlanoraNavy,
    primaryContainer = PlanoraNavyLight,
    onPrimaryContainer = PlanoraIvory,
    secondary = PlanoraGoldLight,
    onSecondary = PlanoraNavy,
    secondaryContainer = PlanoraNavySurface,
    onSecondaryContainer = PlanoraIvory,
    tertiary = PlanoraEmeraldLight,
    onTertiary = PlanoraNavy,
    background = PlanoraNavy,
    onBackground = PlanoraIvory,
    surface = PlanoraNavySurface,
    onSurface = PlanoraIvory,
    surfaceVariant = PlanoraNavyLight,
    onSurfaceVariant = PlanoraBorder,
    outline = PlanoraNavyLight,
    error = PlanoraCrimsonLight,
    onError = PlanoraNavy
)

@Composable
fun PlanoraAiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colorScheme.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
