package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CopilotProposal
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraCrimson
import com.example.ui.theme.PlanoraEmerald
import com.example.ui.theme.PlanoraEmeraldBg
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraNavySurface
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.util.CurrencyUtils
import com.example.viewmodel.ChatMessage
import com.example.viewmodel.EventViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CopilotModalBottomSheet(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val isOpen by viewModel.isCopilotOpen.collectAsState()
    val messages by viewModel.copilotMessages.collectAsState()
    val isThinking by viewModel.isCopilotThinking.collectAsState()
    val highThinking by viewModel.highThinkingEnabled.collectAsState()
    val isListening by viewModel.audioHelper.isListening.collectAsState()
    val transcribedText by viewModel.audioHelper.transcribedText.collectAsState()

    var inputText by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    if (isOpen) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.toggleCopilot(false) },
            sheetState = sheetState,
            containerColor = PlanoraIvory,
            modifier = modifier
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(0.88f)
                    .padding(horizontal = 16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(
                                    androidx.compose.ui.graphics.Brush.linearGradient(
                                        listOf(PlanoraNavy, PlanoraViolet)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_ai_sparkle),
                                contentDescription = "Planora AI",
                                tint = Color.Unspecified,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Planora AI Assistant",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PlanoraNavy
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = PlanoraGold.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "AI",
                                        color = PlanoraNavy,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Powered by Gemini AI • Context: ${viewModel.currentEvent.title}",
                                fontSize = 11.sp,
                                color = PlanoraTextSecondary
                            )
                        }
                    }

                    // High Thinking toggle chip
                    FilterChip(
                        selected = highThinking,
                        onClick = { viewModel.toggleHighThinking() },
                        label = {
                            Text(
                                text = if (highThinking) "Deep Reasoning (3.8-flash)" else "Fast (3.1-flash-lite)",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = "Thinking Mode",
                                modifier = Modifier.size(14.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PlanoraVioletBg,
                            selectedLabelColor = PlanoraViolet,
                            selectedLeadingIconColor = PlanoraViolet
                        ),
                        modifier = Modifier.testTag("high_thinking_toggle")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Suggestion chips
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val promptSuggestions = listOf(
                        "Reduce total budget by 15%",
                        "Change theme to Royal Rajputana Heritage",
                        "Create a two-day timeline",
                        "Suggest cheaper decoration options",
                        "Adjust catering for 300 guests",
                        "Show incomplete tasks"
                    )
                    items(promptSuggestions) { prompt ->
                        Surface(
                            color = PlanoraIvoryMuted,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .clickable {
                                    viewModel.sendCopilotQuery(prompt)
                                }
                        ) {
                            Text(
                                text = prompt,
                                fontSize = 11.sp,
                                color = PlanoraNavy,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Chat Messages List
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(messages) { msg ->
                        ChatBubble(
                            message = msg,
                            onApplyProposal = { proposal ->
                                viewModel.applyCopilotProposal(proposal)
                            },
                            onSpeakText = { text ->
                                viewModel.audioHelper.speak(text)
                            }
                        )
                    }

                    if (isThinking) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp)
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = PlanoraViolet,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = if (highThinking) "Gemini is performing deep contextual reasoning..." else "Generating response...",
                                    fontSize = 12.sp,
                                    color = PlanoraViolet,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Speech recognition indicator
                AnimatedVisibility(visible = isListening) {
                    Surface(
                        color = PlanoraVioletBg,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Listening",
                                tint = PlanoraViolet,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (transcribedText.isNotBlank()) "Listening: \"$transcribedText\"" else "Listening... Speak your command",
                                fontSize = 12.sp,
                                color = PlanoraViolet,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Input Bar with Mic & Send
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = { Text("Ask Planora AI or request changes...", fontSize = 13.sp) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("copilot_input_field"),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PlanoraViolet,
                            unfocusedBorderColor = PlanoraBorder,
                            focusedContainerColor = PlanoraIvoryCard,
                            unfocusedContainerColor = PlanoraIvoryCard
                        ),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Mic Button
                    IconButton(
                        onClick = {
                            if (isListening) {
                                viewModel.audioHelper.stopListening()
                            } else {
                                viewModel.audioHelper.startListening(
                                    onResult = { spoken ->
                                        inputText = spoken
                                        viewModel.sendCopilotQuery(spoken)
                                        inputText = ""
                                    },
                                    onError = { /* Error handled in helper */ }
                                )
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isListening) PlanoraCrimson else PlanoraIvoryCard)
                            .testTag("copilot_mic_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            tint = if (isListening) PlanoraIvory else PlanoraNavy,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Send Button
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                viewModel.sendCopilotQuery(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(PlanoraViolet)
                            .testTag("copilot_send_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = PlanoraIvory,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatBubble(
    message: ChatMessage,
    onApplyProposal: (CopilotProposal) -> Unit,
    onSpeakText: (String) -> Unit
) {
    val isUser = message.sender == "user"

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Surface(
            color = if (isUser) PlanoraNavy else PlanoraIvoryCard,
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth(0.92f)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) "You" else "PLANORA AI",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = if (isUser) PlanoraGold else PlanoraViolet
                    )
                    if (!isUser) {
                        IconButton(
                            onClick = { onSpeakText(message.text) },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Read Aloud",
                                tint = PlanoraViolet,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = message.text,
                    fontSize = 13.sp,
                    color = if (isUser) PlanoraIvory else PlanoraTextPrimary,
                    lineHeight = 18.sp
                )

                // Render Structured Proposal Card with Apply / Discard
                message.proposal?.let { proposal ->
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = if (proposal.isApplied) PlanoraEmeraldBg else PlanoraVioletBg,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (proposal.isApplied) Icons.Default.Check else Icons.Default.AutoAwesome,
                                    contentDescription = "Proposal",
                                    tint = if (proposal.isApplied) PlanoraEmerald else PlanoraViolet,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (proposal.isApplied) "Modifications Applied!" else "Proposed Changes",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = if (proposal.isApplied) PlanoraEmerald else PlanoraViolet
                                )
                            }

                            if (proposal.proposedTheme != null) {
                                Text(
                                    text = "• Theme: ${proposal.proposedTheme}",
                                    fontSize = 12.sp,
                                    color = PlanoraNavy,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                            }

                            if (proposal.budgetAdjustments.isNotEmpty()) {
                                Text(
                                    text = "• Budget Reallocations:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = PlanoraNavy,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                                proposal.budgetAdjustments.forEach { (cat, diff) ->
                                    val sign = if (diff > 0) "+" else ""
                                    Text(
                                        text = "   - ${cat.displayName}: $sign${CurrencyUtils.formatInr(diff)}",
                                        fontSize = 11.sp,
                                        color = if (diff < 0) PlanoraEmerald else PlanoraNavy
                                    )
                                }
                            }

                            if (proposal.addedTasks.isNotEmpty()) {
                                Text(
                                    text = "• New Tasks to Add (${proposal.addedTasks.size}):",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = PlanoraNavy,
                                    modifier = Modifier.padding(top = 4.dp)
                                )
                                proposal.addedTasks.forEach { task ->
                                    Text(
                                        text = "   - $task",
                                        fontSize = 11.sp,
                                        color = PlanoraNavy
                                    )
                                }
                            }

                            if (!proposal.isApplied) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = { onApplyProposal(proposal) },
                                    colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("apply_proposal_btn")
                                ) {
                                    Text(
                                        text = "Apply Planora AI Changes",
                                        color = PlanoraIvory,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
