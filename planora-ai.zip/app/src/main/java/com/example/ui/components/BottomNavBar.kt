package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Checklist
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraNavyLight
import com.example.ui.theme.PlanoraViolet
import com.example.viewmodel.PlanoraScreen

@Composable
fun BottomNavBar(
    currentScreen: PlanoraScreen,
    onSelectScreen: (PlanoraScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = PlanoraNavy,
        contentColor = PlanoraIvory,
        tonalElevation = 8.dp,
        windowInsets = WindowInsets.navigationBars,
        modifier = modifier
    ) {
        val navItems = listOf(
            Triple(PlanoraScreen.DASHBOARD, Icons.Default.Dashboard, "Home"),
            Triple(PlanoraScreen.ARCHITECT, Icons.Default.AutoAwesome, "Architect"),
            Triple(PlanoraScreen.BUDGET, Icons.Default.AccountBalanceWallet, "Budget"),
            Triple(PlanoraScreen.TIMELINE, Icons.Default.Checklist, "Timeline"),
            Triple(PlanoraScreen.VENDORS, Icons.Default.Storefront, "Vendors"),
            Triple(PlanoraScreen.DESIGN, Icons.Default.Palette, "Design"),
            Triple(PlanoraScreen.GUESTS, Icons.Default.Groups, "Guests")
        )

        navItems.forEach { (screen, icon, label) ->
            val isSelected = currentScreen == screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelectScreen(screen) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = screen.title,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = PlanoraNavy,
                    selectedTextColor = PlanoraGold,
                    indicatorColor = PlanoraGold,
                    unselectedIconColor = PlanoraIvory.copy(alpha = 0.65f),
                    unselectedTextColor = PlanoraIvory.copy(alpha = 0.65f)
                ),
                modifier = Modifier.testTag("nav_${screen.name.lowercase()}")
            )
        }
    }
}
