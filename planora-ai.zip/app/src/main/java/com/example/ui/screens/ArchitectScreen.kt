package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.EventType
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraCrimson
import com.example.ui.theme.PlanoraEmerald
import com.example.ui.theme.PlanoraEmeraldBg
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraGoldBg
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraNavySurface
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.util.CurrencyUtils
import com.example.viewmodel.EventViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ArchitectScreen(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val event = viewModel.currentEvent
    val isGenerating by viewModel.isGenerating.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PlanoraIvory)
    ) {
        // Top Action Bar
        Surface(
            color = PlanoraIvoryCard,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "AI Event Architect",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    Text(
                        text = "Full 10-Point Event Blueprint",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                }

                Button(
                    onClick = { showCreateDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("create_new_event_btn")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "New Event",
                        tint = PlanoraIvory,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "New Event",
                        color = PlanoraIvory,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Blueprint Sections List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // 1. Personalized Event Concept
            item {
                BlueprintCard(
                    sectionNumber = "01",
                    title = "Personalized Event Concept",
                    icon = Icons.Default.AutoAwesome,
                    actionText = "Planora AI",
                    onAction = { viewModel.toggleCopilot(true) }
                ) {
                    Text(
                        text = event.concept.title,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = event.concept.overview,
                        fontSize = 12.sp,
                        color = PlanoraTextSecondary,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row {
                        Text(
                            text = "Dress Code: ",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                        Text(
                            text = event.concept.dressCode,
                            fontSize = 11.sp,
                            color = PlanoraTextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Signature Highlights:",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    event.concept.highlights.forEach { hl ->
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text(text = "• ", color = PlanoraGold, fontWeight = FontWeight.Bold)
                            Text(text = hl, fontSize = 11.sp, color = PlanoraTextPrimary, lineHeight = 15.sp)
                        }
                    }
                }
            }

            // 2. Venue Specifications
            item {
                BlueprintCard(
                    sectionNumber = "02",
                    title = "Venue & Infrastructure Requirements",
                    icon = Icons.Default.Apartment
                ) {
                    Text(
                        text = event.venueRequirements.spaceType,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Recommended Layout: ${event.venueRequirements.recommendedLayout}",
                        fontSize = 12.sp,
                        color = PlanoraTextSecondary,
                        lineHeight = 16.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "AV & Acoustics: ${event.venueRequirements.audioVisualNeeds}",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Valet & Parking: ${event.venueRequirements.parkingCapacity}",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Location Advice: ${event.venueRequirements.locationAdvice}",
                        fontSize = 11.sp,
                        color = PlanoraGold,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // 3. Catering & Gastronomy Menu
            item {
                BlueprintCard(
                    sectionNumber = "03",
                    title = "Catering Recommendations & Menu",
                    icon = Icons.Default.Restaurant,
                    actionText = "Regenerate",
                    onAction = { viewModel.regenerateSection("Catering") }
                ) {
                    Text(
                        text = "Service: ${event.cateringMenu.serviceStyle}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Cuisine Highlights: ${event.cateringMenu.cuisineTypes.joinToString(" • ")}",
                        fontSize = 12.sp,
                        color = PlanoraTextSecondary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Signature Appetizers: ${event.cateringMenu.appetizers.joinToString(", ")}",
                        fontSize = 11.sp,
                        color = PlanoraTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Main Courses: ${event.cateringMenu.mainCourses.joinToString(", ")}",
                        fontSize = 11.sp,
                        color = PlanoraTextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Desserts: ${event.cateringMenu.desserts.joinToString(", ")}",
                        fontSize = 11.sp,
                        color = PlanoraGold,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Dietary Care: ${event.cateringMenu.dietaryCoverage}",
                        fontSize = 11.sp,
                        color = PlanoraEmerald,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // 4. Decoration Concept
            item {
                BlueprintCard(
                    sectionNumber = "04",
                    title = "Decoration Concepts & Lighting",
                    icon = Icons.Default.Palette,
                    actionText = "Regenerate",
                    onAction = { viewModel.regenerateSection("Decor") }
                ) {
                    Text(
                        text = event.decorConcept.themeName,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    // Color Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        event.decorConcept.colorPaletteHexes.forEachIndexed { idx, hex ->
                            val color = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(PlanoraGold)
                            Box(
                                modifier = Modifier
                                    .size(26.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .border(1.dp, PlanoraBorder, CircleShape)
                            )
                        }
                        Text(
                            text = event.decorConcept.colorPaletteNames.joinToString(", "),
                            fontSize = 11.sp,
                            color = PlanoraTextSecondary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Stage Setup: ${event.decorConcept.stageSetup}",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Entrance Arch: ${event.decorConcept.entranceArch}",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Lighting: ${event.decorConcept.lightingScheme}",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                }
            }

            // 5. Risk & Contingency Planning
            item {
                BlueprintCard(
                    sectionNumber = "05",
                    title = "Risk & Contingency Plan",
                    icon = Icons.Default.Shield
                ) {
                    event.risks.forEach { risk ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = risk.riskTitle,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PlanoraNavy
                                )
                                Text(
                                    text = "Impact: ${risk.impact}",
                                    fontSize = 10.sp,
                                    color = if (risk.impact == "High") PlanoraCrimson else PlanoraGold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Mitigation: ${risk.mitigationPlan}",
                                fontSize = 11.sp,
                                color = PlanoraTextSecondary,
                                lineHeight = 15.sp
                            )
                        }
                    }
                }
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    // Wizard Dialog to Create New Event with Gemini
    if (showCreateDialog) {
        CreateEventDialog(
            isGenerating = isGenerating,
            onDismiss = { showCreateDialog = false },
            onSubmit = { title, type, date, loc, guests, budget, theme, reqs ->
                viewModel.generateNewEvent(title, type, date, loc, guests, budget, theme, reqs) {
                    showCreateDialog = false
                }
            }
        )
    }
}

@Composable
private fun BlueprintCard(
    sectionNumber: String,
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    actionText: String? = null,
    onAction: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = PlanoraGoldBg,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = sectionNumber,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraGold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                }

                if (actionText != null && onAction != null) {
                    Surface(
                        color = PlanoraVioletBg,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onAction() }
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = actionText,
                                tint = PlanoraViolet,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = actionText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = PlanoraViolet
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            content()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CreateEventDialog(
    isGenerating: Boolean,
    onDismiss: () -> Unit,
    onSubmit: (String, EventType, String, String, Int, Double, String, String) -> Unit
) {
    var title by remember { mutableStateOf("Raipur Grand Wedding Reception") }
    var selectedType by remember { mutableStateOf(EventType.WEDDING) }
    var date by remember { mutableStateOf("18 Dec 2026") }
    var location by remember { mutableStateOf("VIP Road Banquet Lawns, Raipur") }
    var guestCountStr by remember { mutableStateOf("300") }
    var budgetStr by remember { mutableStateOf("800000") }
    var theme by remember { mutableStateOf("Royal Rajputana Heritage") }
    var specialReqs by remember { mutableStateOf("Live Shehnai, Chhattisgarhi delicacies counter") }

    var typeMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = { if (!isGenerating) onDismiss() },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "AI",
                    tint = PlanoraViolet,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("AI Event Architect Wizard", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = PlanoraNavy)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Event Name") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    ExposedDropdownMenuBox(
                        expanded = typeMenuExpanded,
                        onExpandedChange = { typeMenuExpanded = it }
                    ) {
                        OutlinedTextField(
                            value = selectedType.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Event Type") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = typeMenuExpanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor()
                        )
                        ExposedDropdownMenu(
                            expanded = typeMenuExpanded,
                            onDismissRequest = { typeMenuExpanded = false }
                        ) {
                            EventType.entries.forEach { type ->
                                DropdownMenuItem(
                                    text = { Text(type.label) },
                                    onClick = {
                                        selectedType = type
                                        typeMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = date,
                            onValueChange = { date = it },
                            label = { Text("Date") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = guestCountStr,
                            onValueChange = { guestCountStr = it },
                            label = { Text("Guests") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }
                item {
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text("Location / City") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = budgetStr,
                        onValueChange = { budgetStr = it },
                        label = { Text("Total Budget (INR ₹)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Text(
                        text = "Formatted: ${CurrencyUtils.formatInrShort(budgetStr.toDoubleOrNull() ?: 0.0)}",
                        fontSize = 11.sp,
                        color = PlanoraGold,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                item {
                    OutlinedTextField(
                        value = theme,
                        onValueChange = { theme = it },
                        label = { Text("Theme / Aesthetic Preference") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
                item {
                    OutlinedTextField(
                        value = specialReqs,
                        onValueChange = { specialReqs = it },
                        label = { Text("Special Requirements") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val guests = guestCountStr.toIntOrNull() ?: 100
                    val budget = budgetStr.toDoubleOrNull() ?: 500000.0
                    onSubmit(title, selectedType, date, location, guests, budget, theme, specialReqs)
                },
                enabled = !isGenerating && title.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet),
                modifier = Modifier.testTag("submit_generate_event_btn")
            ) {
                if (isGenerating) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = PlanoraIvory,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Synthesizing...")
                } else {
                    Text("Generate with Gemini")
                }
            }
        },
        dismissButton = {
            if (!isGenerating) {
                TextButton(onClick = onDismiss) {
                    Text("Cancel", color = PlanoraTextSecondary)
                }
            }
        }
    )
}
