package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// PLANORA AI Brand Colors - Luxury Modern Event Atelier Palette
val PlanoraNavy = Color(0xFF0B132B)
val PlanoraNavySurface = Color(0xFF1C2541)
val PlanoraNavyLight = Color(0xFF2E3D66)
val PlanoraIvory = Color(0xFFFAF8F5)
val PlanoraIvoryCard = Color(0xFFFFFFFF)
val PlanoraIvoryMuted = Color(0xFFF2ECE4)
val PlanoraViolet = Color(0xFF6C5CE7)
val PlanoraVioletLight = Color(0xFFA29BFE)
val PlanoraVioletBg = Color(0xFFF3F0FF)
val PlanoraGold = Color(0xFFC59B27)
val PlanoraGoldLight = Color(0xFFF9E79F)
val PlanoraGoldBg = Color(0xFFFEF9E7)
val PlanoraEmerald = Color(0xFF00A884)
val PlanoraEmeraldLight = Color(0xFFD1F2EB)
val PlanoraEmeraldBg = Color(0xFFE8F8F5)
val PlanoraCrimson = Color(0xFFD63031)
val PlanoraCrimsonLight = Color(0xFFFF7675)
val PlanoraCrimsonBg = Color(0xFFFDEDEC)
val PlanoraTextPrimary = Color(0xFF0B132B)
val PlanoraTextSecondary = Color(0xFF5A6275)
val PlanoraBorder = Color(0xFFE5DFD5)
val PlanoraChip = Color(0xFFEAE5DC)
