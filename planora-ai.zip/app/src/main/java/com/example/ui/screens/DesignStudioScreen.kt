package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TableRestaurant
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraGoldBg
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraNavySurface
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.viewmodel.EventViewModel

@Composable
fun DesignStudioScreen(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val event = viewModel.currentEvent
    val decor = event.decorConcept

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlanoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Header
            Surface(
                color = PlanoraIvoryCard,
                shape = RoundedCornerShape(16.dp),
                tonalElevation = 2.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "AI Design Studio",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = PlanoraNavy
                            )
                            Text(
                                text = "Themes, Color Swatches, Lighting & Moodboards",
                                fontSize = 11.sp,
                                color = PlanoraTextSecondary
                            )
                        }
                        Surface(
                            color = PlanoraViolet,
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .clickable {
                                    viewModel.toggleCopilot(true)
                                }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "AI Theme",
                                    tint = PlanoraIvory,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("New Theme", color = PlanoraIvory, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Theme Hero Visual Banner
        item {
            val colors = decor.colorPaletteHexes.mapNotNull { hex ->
                runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrNull()
            }.ifEmpty { listOf(PlanoraNavy, PlanoraGold, PlanoraViolet) }

            Card(
                colors = CardDefaults.cardColors(containerColor = PlanoraNavy),
                shape = RoundedCornerShape(18.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(PlanoraNavy, colors.firstOrNull() ?: PlanoraNavySurface)
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Surface(
                            color = PlanoraGold.copy(alpha = 0.25f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "ACTIVE EVENT PALETTE",
                                color = PlanoraGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = decor.themeName,
                            color = PlanoraIvory,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Swatches row with hex values
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            decor.colorPaletteHexes.forEachIndexed { i, hex ->
                                val swatchColor = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(PlanoraGold)
                                val name = decor.colorPaletteNames.getOrNull(i) ?: "Color ${i + 1}"

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(swatchColor)
                                            .border(2.dp, PlanoraIvory.copy(alpha = 0.8f), CircleShape)
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = hex,
                                        color = PlanoraIvory.copy(alpha = 0.8f),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = name,
                                        color = PlanoraGold,
                                        fontSize = 9.sp,
                                        textAlign = TextAlign.Center
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Royal Invitation Card Preview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Mail,
                                contentDescription = "Invitation",
                                tint = PlanoraGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Bespoke Invitation Concept",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = PlanoraNavy
                            )
                        }
                        Surface(
                            color = PlanoraGoldBg,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Digital Card Preview",
                                color = PlanoraGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Invitation Parchment Box
                    Surface(
                        color = PlanoraIvoryMuted,
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, PlanoraGold.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "TOGETHER WITH OUR FAMILIES",
                                fontSize = 10.sp,
                                letterSpacing = 2.sp,
                                color = PlanoraTextSecondary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = event.title,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = PlanoraNavy,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = event.concept.tagline,
                                fontSize = 12.sp,
                                color = PlanoraGold,
                                fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .width(60.dp)
                                    .height(1.dp)
                                    .background(PlanoraGold)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "${event.date} • ${event.location}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium,
                                color = PlanoraNavy,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Dress Code: ${event.concept.dressCode}",
                                fontSize = 11.sp,
                                color = PlanoraTextSecondary
                            )
                        }
                    }
                }
            }
        }

        // Structural Decor Elements
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Spatial & Decor Specifications",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DecorFeatureRow(
                        title = "Stage Architecture",
                        detail = decor.stageSetup,
                        icon = Icons.Default.Palette
                    )

                    DecorFeatureRow(
                        title = "Grand Entrance Arch",
                        detail = decor.entranceArch,
                        icon = Icons.Default.AutoAwesome
                    )

                    DecorFeatureRow(
                        title = "Lighting & Atmosphere",
                        detail = decor.lightingScheme,
                        icon = Icons.Default.Lightbulb
                    )

                    DecorFeatureRow(
                        title = "Guest Table Centerpieces",
                        detail = decor.tableCenterpieces,
                        icon = Icons.Default.TableRestaurant
                    )
                }
            }
        }

        item { Spacer(modifier = Modifier.height(20.dp)) }
    }
}

@Composable
private fun DecorFeatureRow(
    title: String,
    detail: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(PlanoraGoldBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = PlanoraGold,
                modifier = Modifier.size(16.dp)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = PlanoraNavy
            )
            Text(
                text = detail,
                fontSize = 11.sp,
                color = PlanoraTextSecondary,
                lineHeight = 15.sp
            )
        }
    }
}
