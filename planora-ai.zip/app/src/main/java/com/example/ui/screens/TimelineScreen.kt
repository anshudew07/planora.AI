package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TaskItem
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraCrimson
import com.example.ui.theme.PlanoraCrimsonBg
import com.example.ui.theme.PlanoraEmerald
import com.example.ui.theme.PlanoraEmeraldBg
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraGoldBg
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.viewmodel.EventViewModel

@Composable
fun TimelineScreen(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val event = viewModel.currentEvent
    var selectedPhase by remember { mutableStateOf("All") }
    var showAddDialog by remember { mutableStateOf(false) }

    val filteredTasks = if (selectedPhase == "All") {
        event.tasks
    } else {
        event.tasks.filter { it.phase.contains(selectedPhase, ignoreCase = true) }
    }

    val completedCount = event.tasks.count { it.isCompleted }
    val totalCount = event.tasks.size

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PlanoraViolet,
                contentColor = PlanoraIvory,
                shape = CircleShape,
                modifier = Modifier.testTag("add_task_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Task")
            }
        },
        containerColor = PlanoraIvory,
        modifier = modifier
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Header summary
            Surface(
                color = PlanoraIvoryCard,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Timeline & Milestone Tasks",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                        Text(
                            text = "Target Date: ${event.date} • ${event.location}",
                            fontSize = 11.sp,
                            color = PlanoraTextSecondary
                        )
                    }

                    Surface(
                        color = PlanoraEmeraldBg,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "$completedCount / $totalCount Done",
                            color = PlanoraEmerald,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // Phase filters row
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val phases = listOf("All", "Preparation", "1 Month Before", "Event Week", "Event Day")
                items(phases) { phase ->
                    FilterChip(
                        selected = selectedPhase == phase,
                        onClick = { selectedPhase = phase },
                        label = { Text(phase, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = PlanoraNavy,
                            selectedLabelColor = PlanoraIvory,
                            containerColor = PlanoraIvoryCard,
                            labelColor = PlanoraNavy
                        )
                    )
                }
            }

            // Tasks List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredTasks) { task ->
                    TaskCard(
                        task = task,
                        onToggle = { viewModel.toggleTask(task.id) },
                        onDelete = { viewModel.deleteTask(task.id) }
                    )
                }

                item { Spacer(modifier = Modifier.height(70.dp)) }
            }
        }
    }

    if (showAddDialog) {
        AddTaskDialog(
            defaultDate = event.date,
            onDismiss = { showAddDialog = false },
            onAdd = { title, cat, due, priority, phase ->
                viewModel.addTask(title, cat, due, priority, phase)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun TaskCard(
    task: TaskItem,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .testTag("task_item_${task.id.take(6)}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Outlined.Circle,
                contentDescription = "Toggle",
                tint = if (task.isCompleted) PlanoraEmerald else PlanoraBorder,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = task.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (task.isCompleted) PlanoraTextSecondary else PlanoraTextPrimary,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        color = PlanoraIvoryMuted,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = task.category,
                            fontSize = 10.sp,
                            color = PlanoraNavy,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "• ${task.phase} • Due ${task.dueDate}",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Surface(
                color = if (task.priority == "High") PlanoraCrimsonBg else PlanoraGoldBg,
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    text = task.priority,
                    fontSize = 10.sp,
                    color = if (task.priority == "High") PlanoraCrimson else PlanoraGold,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = PlanoraTextSecondary.copy(alpha = 0.6f),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun AddTaskDialog(
    defaultDate: String,
    onDismiss: () -> Unit,
    onAdd: (String, String, String, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Logistics") }
    var dueDate by remember { mutableStateOf(defaultDate) }
    var priority by remember { mutableStateOf("Medium") }
    var phase by remember { mutableStateOf("Preparation") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Milestone Task", fontWeight = FontWeight.Bold, color = PlanoraNavy) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Task Title") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Category (e.g. Venue, Decor, Sound)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = dueDate,
                    onValueChange = { dueDate = it },
                    label = { Text("Due Date") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = phase,
                    onValueChange = { phase = it },
                    label = { Text("Phase (Preparation, Event Week, Event Day)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (title.isNotBlank()) onAdd(title, category, dueDate, priority, phase) },
                colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet),
                enabled = title.isNotBlank()
            ) {
                Text("Add Task")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
