package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.outlined.Check
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraNavySurface
import com.example.ui.theme.PlanoraViolet
import com.example.util.CurrencyUtils
import com.example.viewmodel.EventViewModel

@Composable
fun TopHeaderBar(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val events by viewModel.events.collectAsState()
    val selectedId by viewModel.selectedEventId.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()
    val currentEvent = viewModel.currentEvent
    var isDropdownOpen by remember { mutableStateOf(false) }

    Surface(
        color = PlanoraNavy,
        tonalElevation = 6.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp)
        ) {
            // Brand row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_planora_logo),
                        contentDescription = "PLANORA AI Logo",
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "PLANORA",
                                color = PlanoraIvory,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "AI",
                                color = PlanoraGold,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 17.sp
                            )
                        }
                        Text(
                            text = "Plan Smarter. Celebrate Better.",
                            color = PlanoraIvory.copy(alpha = 0.7f),
                            fontSize = 11.sp
                        )
                    }
                }

                // Action buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Audio Briefing TTS Button
                    IconButton(
                        onClick = {
                            val briefing = "${currentEvent.title} in ${currentEvent.location} on ${currentEvent.date}. " +
                                    "Guest count: ${currentEvent.guestCount}. Total budget is ${CurrencyUtils.formatInrShort(currentEvent.totalBudget)}. " +
                                    "Theme: ${currentEvent.decorConcept.themeName}."
                            viewModel.audioHelper.speak(briefing)
                        },
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("audio_briefing_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Read Aloud Event Briefing",
                            tint = PlanoraGold,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    // Dark / Light Mode Toggle Button
                    IconButton(
                        onClick = { viewModel.toggleTheme() },
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("theme_toggle_btn")
                    ) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Toggle Dark/Light Mode",
                            tint = PlanoraGold,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Reset Demo Scenarios
                    IconButton(
                        onClick = { viewModel.resetToDefaultScenarios() },
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("reset_demo_btn")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset Demo Events",
                            tint = PlanoraIvory.copy(alpha = 0.8f),
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Proper AI Icon & Badge Button with Radiant AI Sparkle
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(PlanoraViolet, Color(0xFF8B5CF6), PlanoraGold)
                                )
                            )
                            .clickable { viewModel.toggleCopilot(true) }
                            .padding(1.5.dp)
                            .testTag("copilot_toggle_btn")
                    ) {
                        Surface(
                            color = PlanoraNavySurface,
                            shape = RoundedCornerShape(18.dp),
                            modifier = Modifier.clip(RoundedCornerShape(18.dp))
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    painter = painterResource(id = R.drawable.ic_ai_sparkle),
                                    contentDescription = "Planora AI",
                                    tint = Color.Unspecified,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "AI",
                                    color = PlanoraGold,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 0.8.sp
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.size(10.dp))

            // Event Selector Pill
            Box(modifier = Modifier.fillMaxWidth()) {
                Surface(
                    color = PlanoraNavySurface,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { isDropdownOpen = true }
                        .testTag("event_selector_dropdown")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = currentEvent.title,
                                    color = PlanoraIvory,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "• ${currentEvent.eventType.label}",
                                    color = PlanoraGold,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = "${currentEvent.location} | ${currentEvent.guestCount} Guests | ${CurrencyUtils.formatInrShort(currentEvent.totalBudget)}",
                                color = PlanoraIvory.copy(alpha = 0.7f),
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ExpandMore,
                            contentDescription = "Select Event",
                            tint = PlanoraIvory
                        )
                    }
                }

                // Dropdown menu showing all events
                DropdownMenu(
                    expanded = isDropdownOpen,
                    onDismissRequest = { isDropdownOpen = false },
                    modifier = Modifier
                        .fillMaxWidth(0.9f)
                        .background(PlanoraNavySurface)
                ) {
                    events.forEach { ev ->
                        DropdownMenuItem(
                            text = {
                                Column {
                                    Text(
                                        text = ev.title,
                                        color = PlanoraIvory,
                                        fontWeight = if (ev.id == selectedId) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "${ev.eventType.label} • ${ev.location} • ${CurrencyUtils.formatInrShort(ev.totalBudget)}",
                                        color = PlanoraGold,
                                        fontSize = 11.sp
                                    )
                                }
                            },
                            trailingIcon = {
                                if (ev.id == selectedId) {
                                    Icon(
                                        imageVector = Icons.Outlined.Check,
                                        contentDescription = "Selected",
                                        tint = PlanoraGold
                                    )
                                }
                            },
                            onClick = {
                                viewModel.selectEvent(ev.id)
                                isDropdownOpen = false
                            }
                        )
                    }
                }
            }
        }
    }
}
