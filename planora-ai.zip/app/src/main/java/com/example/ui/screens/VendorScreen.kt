package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BudgetCategory
import com.example.model.VendorItem
import com.example.model.VendorStatus
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraEmerald
import com.example.ui.theme.PlanoraEmeraldBg
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraGoldBg
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.util.CurrencyUtils
import com.example.viewmodel.EventViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VendorScreen(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val event = viewModel.currentEvent
    var showAddDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = PlanoraViolet,
                contentColor = PlanoraIvory,
                shape = CircleShape,
                modifier = Modifier.testTag("add_vendor_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Vendor")
            }
        },
        containerColor = PlanoraIvory,
        modifier = modifier
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Header
            Surface(
                color = PlanoraIvoryCard,
                tonalElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Vendor Management Workspace",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = PlanoraNavy
                    )
                    Text(
                        text = "Quotations, Contracts & Booking Status • Verified Sample Data",
                        fontSize = 11.sp,
                        color = PlanoraTextSecondary
                    )
                }
            }

            // Vendor notice banner
            Surface(
                color = PlanoraGoldBg,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Notice",
                        tint = PlanoraGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Demo Vendors: All vendor details are clearly labelled as demonstration profiles for testing.",
                        fontSize = 11.sp,
                        color = PlanoraNavy,
                        lineHeight = 15.sp
                    )
                }
            }

            // Vendor list
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(event.vendors) { vendor ->
                    VendorCard(
                        vendor = vendor,
                        onStatusChange = { newStatus ->
                            viewModel.updateVendorStatus(vendor.id, newStatus)
                        },
                        onCall = {
                            val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${vendor.contactPhone}"))
                            runCatching { context.startActivity(intent) }
                        },
                        onEmail = {
                            val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${vendor.email}"))
                            runCatching { context.startActivity(intent) }
                        }
                    )
                }

                item { Spacer(modifier = Modifier.height(70.dp)) }
            }
        }
    }

    if (showAddDialog) {
        AddVendorDialog(
            onDismiss = { showAddDialog = false },
            onAdd = { name, cat, phone, email, quote, status, notes ->
                viewModel.addVendor(name, cat, phone, email, quote, status, notes)
                showAddDialog = false
            }
        )
    }
}

@Composable
private fun VendorCard(
    vendor: VendorItem,
    onStatusChange: (VendorStatus) -> Unit,
    onCall: () -> Unit,
    onEmail: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(PlanoraVioletBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = vendor.name,
                            tint = PlanoraViolet,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = vendor.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = vendor.category.displayName,
                                fontSize = 11.sp,
                                color = PlanoraTextSecondary
                            )
                            if (vendor.isSample) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = PlanoraIvoryMuted,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "SAMPLE",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PlanoraTextSecondary,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Text(
                    text = CurrencyUtils.formatInrWithShort(vendor.quoteAmount),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = PlanoraNavy
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Booking status badge & buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = when (vendor.status) {
                        VendorStatus.BOOKED -> PlanoraEmeraldBg
                        VendorStatus.PAID -> PlanoraGoldBg
                        VendorStatus.QUOTED -> PlanoraVioletBg
                        VendorStatus.INQUIRED -> PlanoraIvoryMuted
                    },
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = vendor.status.label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (vendor.status) {
                            VendorStatus.BOOKED -> PlanoraEmerald
                            VendorStatus.PAID -> PlanoraGold
                            VendorStatus.QUOTED -> PlanoraViolet
                            VendorStatus.INQUIRED -> PlanoraTextSecondary
                        },
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Row {
                    IconButton(onClick = onCall, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Call, contentDescription = "Call", tint = PlanoraEmerald, modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onEmail, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Email, contentDescription = "Email", tint = PlanoraViolet, modifier = Modifier.size(16.dp))
                    }
                }
            }

            if (vendor.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Notes: ${vendor.notes}",
                    fontSize = 11.sp,
                    color = PlanoraTextSecondary
                )
            }

            // Quick Status Changer
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                VendorStatus.entries.forEach { status ->
                    val isCurrent = vendor.status == status
                    Surface(
                        color = if (isCurrent) PlanoraNavy else PlanoraIvoryMuted,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onStatusChange(status) }
                    ) {
                        Text(
                            text = status.name.take(4),
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isCurrent) PlanoraIvory else PlanoraNavy,
                            modifier = Modifier.padding(vertical = 4.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddVendorDialog(
    onDismiss: () -> Unit,
    onAdd: (String, BudgetCategory, String, String, Double, VendorStatus, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(BudgetCategory.CATERING) }
    var phone by remember { mutableStateOf("+91 98000 00000") }
    var email by remember { mutableStateOf("vendor@example.com") }
    var quoteStr by remember { mutableStateOf("50000") }
    var notes by remember { mutableStateOf("") }

    var catMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Vendor Profile", fontWeight = FontWeight.Bold, color = PlanoraNavy) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Vendor / Business Name") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                ExposedDropdownMenuBox(
                    expanded = catMenuExpanded,
                    onExpandedChange = { catMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = category.displayName,
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Category") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = catMenuExpanded) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = catMenuExpanded,
                        onDismissRequest = { catMenuExpanded = false }
                    ) {
                        BudgetCategory.entries.forEach { cat ->
                            DropdownMenuItem(
                                text = { Text(cat.displayName) },
                                onClick = {
                                    category = cat
                                    catMenuExpanded = false
                                }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = quoteStr,
                    onValueChange = { quoteStr = it },
                    label = { Text("Quotation Amount (₹)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Contact Phone") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Quotation Notes / Deliverables") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val quote = quoteStr.toDoubleOrNull() ?: 0.0
                    if (name.isNotBlank()) onAdd(name, category, phone, email, quote, VendorStatus.INQUIRED, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet),
                enabled = name.isNotBlank()
            ) {
                Text("Add Vendor")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
