package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BudgetItem
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraCrimson
import com.example.ui.theme.PlanoraCrimsonBg
import com.example.ui.theme.PlanoraEmerald
import com.example.ui.theme.PlanoraEmeraldBg
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraGoldBg
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraNavyLight
import com.example.ui.theme.PlanoraNavySurface
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.util.CurrencyUtils
import com.example.viewmodel.EventViewModel

@Composable
fun BudgetScreen(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val event = viewModel.currentEvent
    val totalBudget = event.totalBudget
    val totalSpent = CurrencyUtils.calculateTotalSpent(event.budgetItems)
    val totalAllocated = CurrencyUtils.calculateTotalAllocated(event.budgetItems)
    val remainingBalance = CurrencyUtils.calculateRemainingBalance(totalBudget, totalSpent)
    val confirmedSpent = event.budgetItems.filter { it.isConfirmed }.sumOf { it.actualSpent }
    val utilization = CurrencyUtils.calculateUtilizationPercentage(totalBudget, totalSpent)
    val isOverbudget = CurrencyUtils.isOverBudget(totalBudget, totalSpent)

    var editingItem by remember { mutableStateOf<BudgetItem?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(PlanoraIvory)
    ) {
        // Header Banner
        Surface(
            color = PlanoraIvoryCard,
            tonalElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = "Smart Budget Engine",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = PlanoraNavy
                )
                Text(
                    text = "Indian Rupee (INR) Lakh & Crore Tracking • Application-Code Verified",
                    fontSize = 11.sp,
                    color = PlanoraTextSecondary
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }

            // Financial Summary Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = PlanoraNavy),
                    shape = RoundedCornerShape(18.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TOTAL BUDGET",
                                color = PlanoraIvory.copy(alpha = 0.7f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Surface(
                                color = if (isOverbudget) PlanoraCrimson else PlanoraEmerald,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = "${utilization.toInt()}% Utilized",
                                    color = PlanoraIvory,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }

                        Text(
                            text = CurrencyUtils.formatInrWithShort(totalBudget),
                            color = PlanoraIvory,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        LinearProgressIndicator(
                            progress = { (utilization / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = if (isOverbudget) PlanoraCrimson else PlanoraEmerald,
                            trackColor = PlanoraNavyLight,
                            strokeCap = StrokeCap.Round
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SummaryStat(
                                label = "Actual Spent",
                                value = CurrencyUtils.formatInrShort(totalSpent),
                                color = PlanoraGold
                            )
                            SummaryStat(
                                label = "Confirmed",
                                value = CurrencyUtils.formatInrShort(confirmedSpent),
                                color = PlanoraIvory
                            )
                            SummaryStat(
                                label = "Remaining",
                                value = CurrencyUtils.formatInrShort(remainingBalance),
                                color = if (isOverbudget) PlanoraCrimson else PlanoraEmerald
                            )
                        }
                    }
                }
            }

            // Overspending or Allocation Warning
            if (isOverbudget) {
                item {
                    Surface(
                        color = PlanoraCrimsonBg,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = "Alert",
                                tint = PlanoraCrimson,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Budget Overrun Detected",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PlanoraCrimson
                                )
                                Text(
                                    text = "Current expenditures exceed total budget by ${CurrencyUtils.formatInr(totalSpent - totalBudget)}. Ask Planora AI to optimize category allocations.",
                                    fontSize = 11.sp,
                                    color = PlanoraNavy
                                )
                            }
                        }
                    }
                }
            }

            // Category-wise Breakdown Cards
            item {
                Text(
                    text = "Category Allocations & Expense Records",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = PlanoraNavy,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }

            items(event.budgetItems) { item ->
                CategoryBudgetCard(
                    item = item,
                    onEditClick = { editingItem = item }
                )
            }

            item { Spacer(modifier = Modifier.height(20.dp)) }
        }
    }

    // Edit Expense Dialog
    editingItem?.let { item ->
        EditExpenseDialog(
            budgetItem = item,
            onDismiss = { editingItem = null },
            onSave = { spent, isConfirmed, notes ->
                viewModel.updateBudgetItem(item.id, spent, isConfirmed, notes)
                editingItem = null
            }
        )
    }
}

@Composable
private fun SummaryStat(label: String, value: String, color: Color) {
    Column {
        Text(text = label, color = PlanoraIvory.copy(alpha = 0.7f), fontSize = 10.sp)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, color = color, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CategoryBudgetCard(
    item: BudgetItem,
    onEditClick: () -> Unit
) {
    val progress = if (item.allocatedAmount > 0) {
        (item.actualSpent / item.allocatedAmount).toFloat().coerceIn(0f, 1f)
    } else 0f
    val isCategoryOver = item.actualSpent > item.allocatedAmount

    Card(
        colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(PlanoraGoldBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ReceiptLong,
                            contentDescription = item.category.displayName,
                            tint = PlanoraGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = item.category.displayName,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                        Text(
                            text = if (item.isConfirmed) "Contract Confirmed" else "Estimated / In Negotiation",
                            fontSize = 11.sp,
                            color = if (item.isConfirmed) PlanoraEmerald else PlanoraTextSecondary
                        )
                    }
                }

                Surface(
                    color = PlanoraIvoryMuted,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { onEditClick() }
                        .testTag("edit_budget_${item.category.name.lowercase()}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = PlanoraNavy,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Log",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Numbers: Spent vs Allocated
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Spent: ${CurrencyUtils.formatInr(item.actualSpent)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isCategoryOver) PlanoraCrimson else PlanoraNavy
                )
                Text(
                    text = "Budget: ${CurrencyUtils.formatInrShort(item.allocatedAmount)}",
                    fontSize = 12.sp,
                    color = PlanoraTextSecondary
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = if (isCategoryOver) PlanoraCrimson else PlanoraEmerald,
                trackColor = PlanoraIvoryMuted,
                strokeCap = StrokeCap.Round
            )

            if (item.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Note: ${item.notes}",
                    fontSize = 11.sp,
                    color = PlanoraTextSecondary,
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
private fun EditExpenseDialog(
    budgetItem: BudgetItem,
    onDismiss: () -> Unit,
    onSave: (Double, Boolean, String) -> Unit
) {
    var spentStr by remember { mutableStateOf(budgetItem.actualSpent.toInt().toString()) }
    var isConfirmed by remember { mutableStateOf(budgetItem.isConfirmed) }
    var notes by remember { mutableStateOf(budgetItem.notes) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Log Expense: ${budgetItem.category.displayName}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = PlanoraNavy
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "Allocated Budget: ${CurrencyUtils.formatInr(budgetItem.allocatedAmount)}",
                    fontSize = 12.sp,
                    color = PlanoraGold,
                    fontWeight = FontWeight.SemiBold
                )

                OutlinedTextField(
                    value = spentStr,
                    onValueChange = { spentStr = it },
                    label = { Text("Actual Amount Spent (₹)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Vendor Receipt Details") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { isConfirmed = !isConfirmed }
                ) {
                    Checkbox(
                        checked = isConfirmed,
                        onCheckedChange = { isConfirmed = it }
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Mark as Confirmed / Paid Expense",
                        fontSize = 12.sp,
                        color = PlanoraNavy
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amount = spentStr.toDoubleOrNull() ?: budgetItem.actualSpent
                    onSave(amount, isConfirmed, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet)
            ) {
                Text("Save Expense")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
