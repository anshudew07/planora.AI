package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.VendorStatus
import com.example.ui.theme.PlanoraBorder
import com.example.ui.theme.PlanoraCrimson
import com.example.ui.theme.PlanoraCrimsonBg
import com.example.ui.theme.PlanoraEmerald
import com.example.ui.theme.PlanoraEmeraldBg
import com.example.ui.theme.PlanoraGold
import com.example.ui.theme.PlanoraGoldBg
import com.example.ui.theme.PlanoraGoldLight
import com.example.ui.theme.PlanoraIvory
import com.example.ui.theme.PlanoraIvoryCard
import com.example.ui.theme.PlanoraIvoryMuted
import com.example.ui.theme.PlanoraNavy
import com.example.ui.theme.PlanoraNavySurface
import com.example.ui.theme.PlanoraTextPrimary
import com.example.ui.theme.PlanoraTextSecondary
import com.example.ui.theme.PlanoraViolet
import com.example.ui.theme.PlanoraVioletBg
import com.example.util.CurrencyUtils
import com.example.viewmodel.EventViewModel
import com.example.viewmodel.PlanoraScreen

@Composable
fun DashboardScreen(
    viewModel: EventViewModel,
    modifier: Modifier = Modifier
) {
    val event = viewModel.currentEvent

    val totalBudget = event.totalBudget
    val totalSpent = CurrencyUtils.calculateTotalSpent(event.budgetItems)
    val remainingBalance = CurrencyUtils.calculateRemainingBalance(totalBudget, totalSpent)
    val utilization = CurrencyUtils.calculateUtilizationPercentage(totalBudget, totalSpent)
    val isOverbudget = CurrencyUtils.isOverBudget(totalBudget, totalSpent)

    val pendingTasks = event.tasks.count { !it.isCompleted }
    val completedTasks = event.tasks.count { it.isCompleted }
    val bookedVendors = event.vendors.count { it.status == VendorStatus.BOOKED || it.status == VendorStatus.PAID }
    val confirmedGuests = event.guests.filter { it.rsvpStatus == com.example.model.RsvpStatus.CONFIRMED }.sumOf { it.partySize }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(PlanoraIvory)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PlanoraNavy),
                shape = RoundedCornerShape(20.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp)
                    .testTag("dashboard_hero_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = PlanoraGold.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = event.eventType.label,
                                color = PlanoraGold,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                        Surface(
                            color = PlanoraViolet,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = event.status.label,
                                color = PlanoraIvory,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = event.title,
                        color = PlanoraIvory,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = "Location",
                            tint = PlanoraGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = event.location,
                            color = PlanoraIvory.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Icon(
                            imageVector = Icons.Default.CalendarMonth,
                            contentDescription = "Date",
                            tint = PlanoraGold,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = event.date,
                            color = PlanoraIvory.copy(alpha = 0.85f),
                            fontSize = 12.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Concept overview snippet
                    Text(
                        text = "\"${event.concept.tagline}\"",
                        color = PlanoraGoldLight,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Quick action pills inside Hero Card
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.toggleCopilot(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = PlanoraViolet),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("hero_ask_copilot_btn")
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.ic_ai_sparkle),
                                contentDescription = "Planora AI",
                                modifier = Modifier.size(20.dp),
                                tint = Color.Unspecified
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Ask Planora AI",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = PlanoraIvory
                            )
                        }

                        OutlinedButton(
                            onClick = { viewModel.setScreen(PlanoraScreen.ARCHITECT) },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = "View Blueprint",
                                fontSize = 12.sp,
                                color = PlanoraIvory,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Budget Utilization Engine Overview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.setScreen(PlanoraScreen.BUDGET) }
                    .testTag("dashboard_budget_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(PlanoraGoldBg),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = "Budget",
                                    tint = PlanoraGold,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Smart Budget Engine",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PlanoraNavy
                                )
                                Text(
                                    text = "Mathematical Real-Time Tracking (INR)",
                                    fontSize = 11.sp,
                                    color = PlanoraTextSecondary
                                )
                            }
                        }

                        Text(
                            text = "${utilization.toInt()}% Utilized",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isOverbudget) PlanoraCrimson else PlanoraNavy
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Utilization Progress Bar
                    LinearProgressIndicator(
                        progress = { (utilization / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (isOverbudget) PlanoraCrimson else PlanoraEmerald,
                        trackColor = PlanoraIvoryMuted,
                        strokeCap = StrokeCap.Round
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // 3 Metric columns
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        MetricColumn(
                            label = "Total Budget",
                            value = CurrencyUtils.formatInrShort(totalBudget),
                            color = PlanoraNavy
                        )
                        MetricColumn(
                            label = "Actual Spent",
                            value = CurrencyUtils.formatInrShort(totalSpent),
                            color = PlanoraViolet
                        )
                        MetricColumn(
                            label = "Remaining Balance",
                            value = CurrencyUtils.formatInrShort(remainingBalance),
                            color = if (isOverbudget) PlanoraCrimson else PlanoraEmerald
                        )
                    }

                    if (isOverbudget) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            color = PlanoraCrimsonBg,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = "Alert",
                                    tint = PlanoraCrimson,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Overspending warning: expenses exceed budget by ${CurrencyUtils.formatInrShort(totalSpent - totalBudget)}",
                                    fontSize = 11.sp,
                                    color = PlanoraCrimson,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }
            }
        }

        // 4 Fast Stats Grid
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Pending Tasks",
                    value = "$pendingTasks",
                    subtext = "$completedTasks done",
                    icon = Icons.Default.CheckCircle,
                    accentColor = PlanoraViolet,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setScreen(PlanoraScreen.TIMELINE) }
                )
                StatCard(
                    title = "Booked Vendors",
                    value = "$bookedVendors",
                    subtext = "of ${event.vendors.size} total",
                    icon = Icons.Default.Storefront,
                    accentColor = PlanoraGold,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setScreen(PlanoraScreen.VENDORS) }
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(
                    title = "Guest RSVPs",
                    value = "$confirmedGuests",
                    subtext = "of ${event.guestCount} target",
                    icon = Icons.Default.Group,
                    accentColor = PlanoraEmerald,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setScreen(PlanoraScreen.GUESTS) }
                )
                StatCard(
                    title = "Event Theme",
                    value = event.decorConcept.themeName.take(16) + if (event.decorConcept.themeName.length > 16) "..." else "",
                    subtext = "View moodboard",
                    icon = Icons.Default.Palette,
                    accentColor = PlanoraNavy,
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.setScreen(PlanoraScreen.DESIGN) }
                )
            }
        }

        // Active Tasks Preview
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Upcoming Milestones",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                        Text(
                            text = "View All",
                            fontSize = 12.sp,
                            color = PlanoraViolet,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.clickable { viewModel.setScreen(PlanoraScreen.TIMELINE) }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    event.tasks.take(3).forEach { task ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .clickable { viewModel.toggleTask(task.id) },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.CheckCircle,
                                contentDescription = "Check",
                                tint = if (task.isCompleted) PlanoraEmerald else PlanoraBorder,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = task.title,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = if (task.isCompleted) PlanoraTextSecondary else PlanoraTextPrimary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${task.phase} • Due ${task.dueDate}",
                                    fontSize = 11.sp,
                                    color = PlanoraTextSecondary
                                )
                            }
                            Surface(
                                color = if (task.priority == "High") PlanoraCrimsonBg else PlanoraIvoryMuted,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    text = task.priority,
                                    fontSize = 10.sp,
                                    color = if (task.priority == "High") PlanoraCrimson else PlanoraTextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Demo Walkthrough helper notice
        item {
            Surface(
                color = PlanoraGoldBg,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.TrendingUp,
                        contentDescription = "Demo",
                        tint = PlanoraGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Competition Demonstration Ready",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = PlanoraNavy
                        )
                        Text(
                            text = "Demonstrate Raipur Wedding Reception (300 guests, ₹8 Lakh), Planora AI theme adjustments, and live budget updates.",
                            fontSize = 11.sp,
                            color = PlanoraTextSecondary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricColumn(label: String, value: String, color: Color) {
    Column {
        Text(text = label, fontSize = 11.sp, color = PlanoraTextSecondary)
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
    }
}

@Composable
private fun StatCard(
    title: String,
    value: String,
    subtext: String,
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = PlanoraIvoryCard),
        shape = RoundedCornerShape(14.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    color = PlanoraTextSecondary,
                    fontWeight = FontWeight.Medium
                )
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = PlanoraNavy
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtext,
                fontSize = 11.sp,
                color = PlanoraTextSecondary
            )
        }
    }
}
