package com.example.ai

import android.util.Log
import com.example.BuildConfig
import com.example.model.BudgetItem
import com.example.model.BudgetCategory
import com.example.model.CateringMenu
import com.example.model.CopilotProposal
import com.example.model.DecorConcept
import com.example.model.EventConcept
import com.example.model.EventModel
import com.example.model.EventStatus
import com.example.model.EventType
import com.example.model.GuestItem
import com.example.model.RiskContingency
import com.example.model.RsvpStatus
import com.example.model.TaskItem
import com.example.model.VendorItem
import com.example.model.VendorStatus
import com.example.model.VenueRequirements
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

private const val TAG = "GeminiEventService"

sealed interface AiResult<out T> {
    data class Success<T>(val data: T, val isLiveAi: Boolean, val modelUsed: String) : AiResult<T>
    data class Error(val message: String, val canFallback: Boolean = true) : AiResult<Nothing>
}

class GeminiEventService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val apiKey: String
        get() = try {
            val key = BuildConfig.GEMINI_API_KEY
            if (key.isNullOrBlank() || key == "MY_GEMINI_API_KEY") "" else key
        } catch (e: Exception) {
            ""
        }

    /**
     * Generates a complete 10-point Event Blueprint using Gemini 3.8 Flash
     */
    suspend fun generateEventBlueprint(
        title: String,
        eventType: EventType,
        date: String,
        location: String,
        guestCount: Int,
        totalBudget: Double,
        themePreference: String,
        specialRequirements: String
    ): AiResult<EventModel> = withContext(Dispatchers.IO) {
        val modelName = "gemini-3.8-flash"

        if (apiKey.isBlank()) {
            Log.w(TAG, "API key not configured in secrets. Using high-fidelity intelligent domain architect.")
            val model = buildDeterministicBlueprint(
                title, eventType, date, location, guestCount, totalBudget, themePreference, specialRequirements
            )
            return@withContext AiResult.Success(model, isLiveAi = false, modelUsed = "Planora Native Architect Engine")
        }

        val prompt = """
            You are PLANORA AI, an elite event planner and software architect.
            Generate a comprehensive, mathematically consistent event blueprint in strictly valid JSON format.
            Do NOT enclose in markdown code fences. Output raw JSON only.
            
            Event Details:
            - Title: $title
            - Type: ${eventType.label}
            - Date: $date
            - Location: $location
            - Guest Count: $guestCount
            - Total Budget: ₹$totalBudget INR
            - Theme Preference: $themePreference
            - Special Requirements: $specialRequirements
            
            JSON Structure Required:
            {
              "concept": {
                "title": "string",
                "tagline": "string",
                "overview": "string",
                "atmosphere": "string",
                "dressCode": "string",
                "highlights": ["string", "string", "string", "string"]
              },
              "venueRequirements": {
                "spaceType": "string",
                "capacityRequired": $guestCount,
                "recommendedLayout": "string",
                "audioVisualNeeds": "string",
                "parkingCapacity": "string",
                "locationAdvice": "string"
              },
              "cateringMenu": {
                "serviceStyle": "string",
                "cuisineTypes": ["string", "string"],
                "welcomeDrinks": ["string", "string"],
                "appetizers": ["string", "string", "string"],
                "mainCourses": ["string", "string", "string"],
                "desserts": ["string", "string"],
                "dietaryCoverage": "string"
              },
              "decorConcept": {
                "themeName": "string",
                "colorPaletteNames": ["string", "string", "string", "string"],
                "colorPaletteHexes": ["#RRGGBB", "#RRGGBB", "#RRGGBB", "#RRGGBB"],
                "stageSetup": "string",
                "entranceArch": "string",
                "lightingScheme": "string",
                "tableCenterpieces": "string"
              },
              "budgetDistributionPercent": {
                "VENUE": 28.0,
                "CATERING": 35.0,
                "DECORATION": 16.0,
                "PHOTOGRAPHY": 8.0,
                "ENTERTAINMENT": 5.0,
                "TRANSPORTATION": 3.0,
                "ACCOMMODATION": 3.0,
                "MISCELLANEOUS": 2.0
              },
              "tasks": [
                {"title": "string", "category": "string", "dueDate": "string", "priority": "High", "phase": "Preparation"}
              ],
              "risks": [
                {"riskTitle": "string", "impact": "High|Moderate|Low", "mitigationPlan": "string"}
              ]
            }
        """.trimIndent()

        try {
            val responseJson = callGeminiApi(modelName, prompt)
            val eventModel = parseBlueprintJson(
                responseJson, title, eventType, date, location, guestCount, totalBudget, themePreference, specialRequirements
            )
            AiResult.Success(eventModel, isLiveAi = true, modelUsed = modelName)
        } catch (e: Exception) {
            Log.w(TAG, "Gemini generation notice: ${e.message}. Using offline domain architect.")
            val fallbackModel = buildDeterministicBlueprint(
                title, eventType, date, location, guestCount, totalBudget, themePreference, specialRequirements
            )
            AiResult.Success(fallbackModel, isLiveAi = false, modelUsed = "Planora Native Architect Engine")
        }
    }

    /**
     * AI Planning Copilot: processes user natural language requests with High-Thinking reasoning
     */
    suspend fun queryCopilot(
        event: EventModel,
        userQuery: String,
        enableHighThinking: Boolean = true
    ): AiResult<CopilotProposal> = withContext(Dispatchers.IO) {
        val modelName = if (enableHighThinking) "gemini-3.8-flash" else "gemini-3.1-flash-lite"

        if (apiKey.isBlank()) {
            val deterministicProposal = buildDeterministicCopilotProposal(event, userQuery)
            return@withContext AiResult.Success(deterministicProposal, isLiveAi = false, modelUsed = "Planora AI Reasoning Engine")
        }

        val prompt = """
            You are the PLANORA AI Event Planning Copilot.
            Current Event Context:
            - Name: ${event.title} (${event.eventType.label})
            - Total Budget: ₹${event.totalBudget} INR
            - Guest Count: ${event.guestCount}
            - Current Theme: ${event.decorConcept.themeName}
            - Current Categories:
              Venue: ₹${event.budgetItems.find { it.category == BudgetCategory.VENUE }?.allocatedAmount ?: 0}
              Catering: ₹${event.budgetItems.find { it.category == BudgetCategory.CATERING }?.allocatedAmount ?: 0}
              Decor: ₹${event.budgetItems.find { it.category == BudgetCategory.DECORATION }?.allocatedAmount ?: 0}
            
            User Command: "$userQuery"
            
            Formulate a clear response, professional reasoning, and structured changes.
            Output raw valid JSON without markdown code fences.
            {
              "summary": "1-2 sentence actionable summary of changes",
              "reasoning": "Logistical and financial reasoning for this adjustment",
              "proposedTheme": "new theme name or null",
              "budgetAdjustments": {
                "VENUE": 0,
                "CATERING": -20000,
                "DECORATION": 20000
              },
              "addedTasks": ["New task 1", "New task 2"]
            }
        """.trimIndent()

        try {
            val responseJson = callGeminiApi(modelName, prompt)
            val proposal = parseCopilotJson(responseJson)
            AiResult.Success(proposal, isLiveAi = true, modelUsed = modelName)
        } catch (e: Exception) {
            Log.w(TAG, "Copilot using high-fidelity offline fallback: ${e.message}")
            val fallbackProposal = buildDeterministicCopilotProposal(event, userQuery)
            AiResult.Success(fallbackProposal, isLiveAi = false, modelUsed = "Planora AI Offline Engine")
        }
    }

    private fun callGeminiApi(modelName: String, promptText: String): String {
        val cleanModel = modelName.removePrefix("models/")
        val url = "https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:generateContent?key=$apiKey"

        val jsonPayload = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply {
                            put("text", promptText)
                        })
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.4)
            })
        }

        val body = jsonPayload.toString().toRequestBody("application/json".toMediaType())
        val request = Request.Builder()
            .url(url)
            .post(body)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errorBody = response.body?.string().orEmpty()
                throw IllegalStateException("Gemini API HTTP ${response.code}: $errorBody")
            }
            val responseString = response.body?.string().orEmpty()
            val root = JSONObject(responseString)
            val candidates = root.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                throw IllegalStateException("No candidates returned from Gemini.")
            }
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.getJSONObject("content")
            val parts = content.getJSONArray("parts")
            val text = parts.getJSONObject(0).getString("text")
            return text.trim()
        }
    }

    private fun parseBlueprintJson(
        jsonString: String,
        title: String,
        eventType: EventType,
        date: String,
        location: String,
        guestCount: Int,
        totalBudget: Double,
        themePreference: String,
        specialRequirements: String
    ): EventModel {
        // Strip markdown fences if present
        val clean = jsonString.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val json = JSONObject(clean)

        val conceptObj = json.optJSONObject("concept") ?: JSONObject()
        val concept = EventConcept(
            title = conceptObj.optString("title", "$title Concept"),
            tagline = conceptObj.optString("tagline", "Elegantly planned with PLANORA AI"),
            overview = conceptObj.optString("overview", "Custom tailored event in $location for $guestCount guests."),
            atmosphere = conceptObj.optString("atmosphere", "Celebratory, refined and unforgettable."),
            dressCode = conceptObj.optString("dressCode", "Formal Celebration Attire"),
            highlights = parseStringList(conceptObj.optJSONArray("highlights"))
        )

        val venueObj = json.optJSONObject("venueRequirements") ?: JSONObject()
        val venue = VenueRequirements(
            spaceType = venueObj.optString("spaceType", "Banquet Hall & Lawns"),
            capacityRequired = venueObj.optInt("capacityRequired", guestCount + 30),
            recommendedLayout = venueObj.optString("recommendedLayout", "Round tables with clear stage visibility"),
            audioVisualNeeds = venueObj.optString("audioVisualNeeds", "Line array audio, wireless microphones & LED screen"),
            parkingCapacity = venueObj.optString("parkingCapacity", "${(guestCount / 3).coerceAtLeast(30)} cars"),
            locationAdvice = venueObj.optString("locationAdvice", "Centrally accessible in $location")
        )

        val caterObj = json.optJSONObject("cateringMenu") ?: JSONObject()
        val catering = CateringMenu(
            serviceStyle = caterObj.optString("serviceStyle", "Buffet with Live Counters"),
            cuisineTypes = parseStringList(caterObj.optJSONArray("cuisineTypes")),
            welcomeDrinks = parseStringList(caterObj.optJSONArray("welcomeDrinks")),
            appetizers = parseStringList(caterObj.optJSONArray("appetizers")),
            mainCourses = parseStringList(caterObj.optJSONArray("mainCourses")),
            desserts = parseStringList(caterObj.optJSONArray("desserts")),
            dietaryCoverage = caterObj.optString("dietaryCoverage", "Vegetarian, Vegan & Non-Vegetarian options clearly separated")
        )

        val decorObj = json.optJSONObject("decorConcept") ?: JSONObject()
        val decor = DecorConcept(
            themeName = decorObj.optString("themeName", themePreference.ifBlank { "Modern Luxury Elegance" }),
            colorPaletteNames = parseStringList(decorObj.optJSONArray("colorPaletteNames")),
            colorPaletteHexes = parseStringList(decorObj.optJSONArray("colorPaletteHexes")),
            stageSetup = decorObj.optString("stageSetup", "Elevated focal backdrop with floral accents"),
            entranceArch = decorObj.optString("entranceArch", "Grand welcome arch with branded signage"),
            lightingScheme = decorObj.optString("lightingScheme", "Warm ambient wash with accent spotlights"),
            tableCenterpieces = decorObj.optString("tableCenterpieces", "Custom floral and candle arrangements")
        )

        // Mathematical Budget Calculation in Application Code
        val budgetDist = json.optJSONObject("budgetDistributionPercent")
        val budgetItems = calculateBudgetItems(totalBudget, budgetDist)

        val tasksArray = json.optJSONArray("tasks")
        val tasks = mutableListOf<TaskItem>()
        if (tasksArray != null) {
            for (i in 0 until tasksArray.length()) {
                val tObj = tasksArray.getJSONObject(i)
                tasks.add(
                    TaskItem(
                        id = UUID.randomUUID().toString(),
                        title = tObj.optString("title", "Task ${i + 1}"),
                        category = tObj.optString("category", "General"),
                        dueDate = tObj.optString("dueDate", date),
                        isCompleted = false,
                        priority = tObj.optString("priority", "Medium"),
                        phase = tObj.optString("phase", "Preparation")
                    )
                )
            }
        }
        if (tasks.isEmpty()) {
            tasks.addAll(getDefaultTasks(date))
        }

        val risksArray = json.optJSONArray("risks")
        val risks = mutableListOf<RiskContingency>()
        if (risksArray != null) {
            for (i in 0 until risksArray.length()) {
                val rObj = risksArray.getJSONObject(i)
                risks.add(
                    RiskContingency(
                        id = UUID.randomUUID().toString(),
                        riskTitle = rObj.optString("riskTitle", "Logistical Risk ${i + 1}"),
                        impact = rObj.optString("impact", "Moderate"),
                        mitigationPlan = rObj.optString("mitigationPlan", "Active vendor coordination.")
                    )
                )
            }
        }

        return EventModel(
            id = UUID.randomUUID().toString(),
            title = title,
            eventType = eventType,
            date = date,
            location = location,
            guestCount = guestCount,
            totalBudget = totalBudget,
            themePreference = themePreference,
            specialRequirements = specialRequirements,
            status = EventStatus.PLANNING,
            concept = concept,
            venueRequirements = venue,
            cateringMenu = catering,
            decorConcept = decor,
            budgetItems = budgetItems,
            tasks = tasks,
            vendors = getDefaultVendors(budgetItems),
            guests = getDefaultGuests(guestCount),
            risks = risks.ifEmpty { getDefaultRisks() }
        )
    }

    private fun parseCopilotJson(jsonString: String): CopilotProposal {
        val clean = jsonString.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val json = JSONObject(clean)
        val summary = json.optString("summary", "Proposed optimization based on your request.")
        val reasoning = json.optString("reasoning", "Aligned with standard industry event parameters.")
        val proposedTheme = if (json.has("proposedTheme") && !json.isNull("proposedTheme")) json.getString("proposedTheme") else null

        val adjustments = mutableMapOf<BudgetCategory, Double>()
        val adjObj = json.optJSONObject("budgetAdjustments")
        if (adjObj != null) {
            for (key in adjObj.keys()) {
                val cat = BudgetCategory.entries.find { it.name.equals(key, ignoreCase = true) }
                if (cat != null) {
                    adjustments[cat] = adjObj.optDouble(key, 0.0)
                }
            }
        }

        val tasksList = parseStringList(json.optJSONArray("addedTasks"))

        return CopilotProposal(
            id = UUID.randomUUID().toString(),
            summary = summary,
            reasoning = reasoning,
            proposedTheme = proposedTheme,
            budgetAdjustments = adjustments,
            addedTasks = tasksList,
            isApplied = false
        )
    }

    private fun parseStringList(jsonArray: JSONArray?): List<String> {
        if (jsonArray == null) return emptyList()
        val list = mutableListOf<String>()
        for (i in 0 until jsonArray.length()) {
            list.add(jsonArray.optString(i))
        }
        return list
    }

    /**
     * Strict Mathematical application-code allocation: sums up to exact totalBudget.
     */
    private fun calculateBudgetItems(totalBudget: Double, percentsJson: JSONObject?): List<BudgetItem> {
        val defaultPercents = mapOf(
            BudgetCategory.VENUE to 0.28,
            BudgetCategory.CATERING to 0.35,
            BudgetCategory.DECORATION to 0.16,
            BudgetCategory.PHOTOGRAPHY to 0.08,
            BudgetCategory.ENTERTAINMENT to 0.05,
            BudgetCategory.TRANSPORTATION to 0.03,
            BudgetCategory.ACCOMMODATION to 0.03,
            BudgetCategory.MISCELLANEOUS to 0.02
        )

        var runningAllocated = 0.0
        val items = mutableListOf<BudgetItem>()

        val categories = BudgetCategory.entries
        for (i in categories.indices) {
            val cat = categories[i]
            val pct = if (percentsJson != null && percentsJson.has(cat.name)) {
                percentsJson.optDouble(cat.name, defaultPercents[cat]!! * 100.0) / 100.0
            } else {
                defaultPercents[cat] ?: 0.05
            }

            // For the last item, ensure the sum matches totalBudget exactly without floating point drift
            val amount = if (i == categories.lastIndex) {
                (totalBudget - runningAllocated).coerceAtLeast(0.0)
            } else {
                val calculated = kotlin.math.round((totalBudget * pct) / 500.0) * 500.0
                calculated
            }

            runningAllocated += amount
            items.add(
                BudgetItem(
                    id = UUID.randomUUID().toString(),
                    category = cat,
                    allocatedAmount = amount,
                    actualSpent = 0.0,
                    isConfirmed = false,
                    notes = "Recommended allocation for ${cat.displayName}"
                )
            )
        }
        return items
    }

    /**
     * High-fidelity deterministic architect fallback (works offline and when no API key is provided)
     */
    fun buildDeterministicBlueprint(
        title: String,
        eventType: EventType,
        date: String,
        location: String,
        guestCount: Int,
        totalBudget: Double,
        themePreference: String,
        specialRequirements: String
    ): EventModel {
        val themeName = themePreference.ifBlank {
            when (eventType) {
                EventType.WEDDING -> "Royal Heritage & Velvet Twilight"
                EventType.CORPORATE -> "Modern Cyber Minimalist"
                EventType.ANNIVERSARY -> "Romantic Lakeside Candlelight"
                EventType.BIRTHDAY -> "Electric Neon Retro"
                EventType.CULTURAL -> "Traditional Cultural Splendor"
                EventType.CUSTOM -> "Artisanal Boutique Celebration"
            }
        }

        val budgetItems = calculateBudgetItems(totalBudget, null)
        val defaultTasks = getDefaultTasks(date)

        return EventModel(
            id = UUID.randomUUID().toString(),
            title = title,
            eventType = eventType,
            date = date,
            location = location,
            guestCount = guestCount,
            totalBudget = totalBudget,
            themePreference = themePreference,
            specialRequirements = specialRequirements,
            status = EventStatus.PLANNING,
            concept = EventConcept(
                title = "$title Master Concept",
                tagline = "Curated luxury event designed by PLANORA AI for $guestCount guests.",
                overview = "A seamless celebration crafted for $location with optimal guest flow, bespoke hospitality, and synchronized logistics.",
                atmosphere = "Warm, refined, visually breathtaking, and joyous.",
                dressCode = if (eventType == EventType.WEDDING) "Royal Ethnic Formal" else "Smart Semi-Formal",
                highlights = listOf(
                    "Grand thematic entrance with branded photo-wall installation",
                    "Signature culinary live stations and artisanal beverage pairing",
                    "Acoustic and ambient lighting transitions between day and night",
                    "Personalized guest welcome favors and digital itinerary integration"
                )
            ),
            venueRequirements = VenueRequirements(
                spaceType = if (eventType == EventType.WEDDING) "Banquet Lawn + Grand Foyer" else "Ballroom & Terrace Lounge",
                capacityRequired = (guestCount * 1.15).toInt(),
                recommendedLayout = "Central aisle with circular dining clusters (8-10 pax) and elevated stage",
                audioVisualNeeds = "Dual high-definition LED displays, multi-channel sound mixer, handheld wireless mics",
                parkingCapacity = "Valet parking for ${(guestCount / 2.5).toInt()} vehicles",
                locationAdvice = "Easily accessible from major arterial roads in $location"
            ),
            cateringMenu = CateringMenu(
                serviceStyle = "Interactive Gourmet Buffet with Signature Live Counters",
                cuisineTypes = listOf("Regional Gourmet Specialty", "Pan-Asian Wok", "Continental Lite", "Artisanal Confectionery"),
                welcomeDrinks = listOf("Fresh Fruit Sparklers", "Signature Spiced Infusion", "Chilled Tender Coconut Water"),
                appetizers = listOf("Smoked Cottage Cheese Skewers", "Crispy Corn & Water Chestnut Cones", "Tandoori Chicken Sliders", "Steamed Dim Sums"),
                mainCourses = listOf("Signature Dal Bukhara", "Paneer Lababdar", "Seasonal Vegetable Medley", "Biryani with Mirch Baingan Salan"),
                desserts = listOf("Saffron Infused Jalebi with Cream", "Warm Chocolate Fondant", "Assorted Gourmet Kulfi"),
                dietaryCoverage = "Clear dietary labels provided for all dietary preferences"
            ),
            decorConcept = DecorConcept(
                themeName = themeName,
                colorPaletteNames = listOf("Imperial Gold", "Deep Indigo", "Warm Ivory", "Forest Sage"),
                colorPaletteHexes = listOf("#C59B27", "#1C2541", "#FAF8F5", "#2E7D32"),
                stageSetup = "Architectural framework with warm ambient backlights and fresh floral cascades",
                entranceArch = "Grand curved archway with cascading botanicals and warm micro-fairy lights",
                lightingScheme = "Soft 2700K ambient wash complemented by architectural uplights",
                tableCenterpieces = "Handcrafted metallic urns with fresh blossoms and scented glass votives"
            ),
            budgetItems = budgetItems,
            tasks = defaultTasks,
            vendors = getDefaultVendors(budgetItems),
            guests = getDefaultGuests(guestCount),
            risks = getDefaultRisks()
        )
    }

    private fun buildDeterministicCopilotProposal(event: EventModel, query: String): CopilotProposal {
        val lower = query.lowercase()
        return when {
            lower.contains("reduce") || lower.contains("cut") || lower.contains("lower") || lower.contains("15%") -> {
                val cateringItem = event.budgetItems.find { it.category == BudgetCategory.CATERING }
                val decorItem = event.budgetItems.find { it.category == BudgetCategory.DECORATION }
                val cateringCut = (cateringItem?.allocatedAmount ?: 50000.0) * 0.10
                val decorCut = (decorItem?.allocatedAmount ?: 30000.0) * 0.15

                CopilotProposal(
                    id = UUID.randomUUID().toString(),
                    summary = "Proposed 10-15% cost optimization across Catering and Decor.",
                    reasoning = "Optimizing live counter count and switching to locally sourced seasonal florals saves ₹${(cateringCut + decorCut).toInt()} without compromising guest experience.",
                    budgetAdjustments = mapOf(
                        BudgetCategory.CATERING to -cateringCut,
                        BudgetCategory.DECORATION to -decorCut,
                        BudgetCategory.MISCELLANEOUS to (cateringCut + decorCut) * 0.5
                    ),
                    addedTasks = listOf("Request revised seasonal floral estimate", "Finalize optimized live counter list with caterer")
                )
            }
            lower.contains("theme") || lower.contains("royal") || lower.contains("rajputana") -> {
                CopilotProposal(
                    id = UUID.randomUUID().toString(),
                    summary = "Proposed theme switch to 'Royal Rajputana Heritage & Marigold Splendor'.",
                    reasoning = "Features brass urli centerpieces, marigold garlands, and imperial red accents for maximum cultural grandeur.",
                    proposedTheme = "Royal Rajputana Heritage & Marigold Splendor",
                    budgetAdjustments = emptyMap(),
                    addedTasks = listOf("Review brass urli table centerpieces with decorator", "Add traditional royal dhol welcome to timeline")
                )
            }
            lower.contains("timeline") || lower.contains("2-day") || lower.contains("two-day") -> {
                CopilotProposal(
                    id = UUID.randomUUID().toString(),
                    summary = "Structured 2-day event schedule expansion.",
                    reasoning = "Separates preparatory/rehearsal evening from main event day to eliminate rush and stress.",
                    addedTasks = listOf(
                        "Day 1: Evening Welcome Dinner & AV Technical Soundcheck",
                        "Day 2: Morning Decor Handover & Vendor Assembly",
                        "Day 2: Grand Evening Reception & Stage Program"
                    )
                )
            }
            else -> {
                CopilotProposal(
                    id = UUID.randomUUID().toString(),
                    summary = "Evaluated current event parameters: ${event.title}.",
                    reasoning = "All 8 budget categories are balanced. You have ${event.tasks.count { !it.isCompleted }} pending tasks remaining before the event.",
                    addedTasks = listOf("Conduct comprehensive vendor status review 1 week prior")
                )
            }
        }
    }

    private fun getDefaultTasks(eventDate: String): List<TaskItem> {
        return listOf(
            TaskItem(UUID.randomUUID().toString(), "Confirm venue booking and deposit contract", "Venue", eventDate, false, "High", "Preparation"),
            TaskItem(UUID.randomUUID().toString(), "Finalize menu tasting with catering team", "Catering", eventDate, false, "High", "Preparation"),
            TaskItem(UUID.randomUUID().toString(), "Review 3D stage and lighting render", "Decor", eventDate, false, "Medium", "1 Month Before"),
            TaskItem(UUID.randomUUID().toString(), "Dispatch digital RSVP invitations to guest list", "Guests", eventDate, false, "High", "1 Month Before"),
            TaskItem(UUID.randomUUID().toString(), "Coordinate soundcheck with AV & audio technicians", "AV", eventDate, false, "High", "Event Week"),
            TaskItem(UUID.randomUUID().toString(), "Final walk-through with event coordinator", "Operations", eventDate, false, "High", "Event Day")
        )
    }

    private fun getDefaultVendors(budgetItems: List<BudgetItem>): List<VendorItem> {
        val venueItem = budgetItems.find { it.category == BudgetCategory.VENUE }
        val caterItem = budgetItems.find { it.category == BudgetCategory.CATERING }
        val decorItem = budgetItems.find { it.category == BudgetCategory.DECORATION }

        return listOf(
            VendorItem(
                id = UUID.randomUUID().toString(),
                name = "Elite Grand Lawns & Banquets (Demo)",
                category = BudgetCategory.VENUE,
                contactPhone = "+91 98200 12345",
                email = "bookings@elitelawns.demo",
                quoteAmount = venueItem?.allocatedAmount ?: 150000.0,
                status = VendorStatus.QUOTED,
                isSample = true,
                notes = "Sample demo vendor for demonstration"
            ),
            VendorItem(
                id = UUID.randomUUID().toString(),
                name = "Royal Feast Gourmet Caterers (Demo)",
                category = BudgetCategory.CATERING,
                contactPhone = "+91 98300 54321",
                email = "contact@royalfeast.demo",
                quoteAmount = caterItem?.allocatedAmount ?: 200000.0,
                status = VendorStatus.INQUIRED,
                isSample = true,
                notes = "Sample demo vendor for demonstration"
            ),
            VendorItem(
                id = UUID.randomUUID().toString(),
                name = "Aura Floral & Event Stylists (Demo)",
                category = BudgetCategory.DECORATION,
                contactPhone = "+91 98400 98765",
                email = "styling@auradecor.demo",
                quoteAmount = decorItem?.allocatedAmount ?: 100000.0,
                status = VendorStatus.INQUIRED,
                isSample = true,
                notes = "Sample demo vendor for demonstration"
            )
        )
    }

    private fun getDefaultGuests(guestCount: Int): List<GuestItem> {
        return listOf(
            GuestItem(UUID.randomUUID().toString(), "Primary Host Family", "Family", RsvpStatus.CONFIRMED, (guestCount * 0.15).toInt().coerceAtLeast(4), "Vegetarian"),
            GuestItem(UUID.randomUUID().toString(), "Extended Relatives Circle", "Family", RsvpStatus.CONFIRMED, (guestCount * 0.25).toInt().coerceAtLeast(8), "Mixed"),
            GuestItem(UUID.randomUUID().toString(), "Executive VIP Guests", "VIP", RsvpStatus.CONFIRMED, 10, "Special Dietary"),
            GuestItem(UUID.randomUUID().toString(), "Friends & Alumni Group", "Friends", RsvpStatus.PENDING, (guestCount * 0.30).toInt().coerceAtLeast(10), "Standard"),
            GuestItem(UUID.randomUUID().toString(), "Corporate & Business Associates", "Corporate", RsvpStatus.PENDING, (guestCount * 0.20).toInt().coerceAtLeast(6), "Standard")
        )
    }

    private fun getDefaultRisks(): List<RiskContingency> {
        return listOf(
            RiskContingency(UUID.randomUUID().toString(), "Sudden Weather Shift / Rain", "High", "Contract backup waterproof tensile marquee and keep indoor banquet foyer clear."),
            RiskContingency(UUID.randomUUID().toString(), "Sound Equipment or AV Power Trip", "Moderate", "Deploy dual silent generators with automatic auto-transfer switch on standby."),
            RiskContingency(UUID.randomUUID().toString(), "Guest Over-attendance (+15%)", "Moderate", "Instruct caterer to maintain a 15% raw ingredient buffer in galley kitchen.")
        )
    }
}
