# PLANORA AI

> **Plan Smarter. Celebrate Better.**  
> A premium, intelligent, full-stack AI-powered event planning and management platform built for Android with Jetpack Compose and Google Gemini AI.

---

## 🌟 Key Features

1. **AI Event Architect**:
   - Generates comprehensive 10-point event blueprints: Personalized Event Concepts, Budget Allocations, Venue Specifications, Catering Blueprints, Decor Schemes, Vendor Requirements, Timelines, Guest Plans, Checklists, and Risk Contingencies.
   - Intelligent regeneration of individual sections without overwriting the rest of the plan.

2. **Smart Budget Engine**:
   - Financial management in Indian Rupee (**INR ₹ with Lakh and Crore formatting**).
   - Real-time expense tracking, category-wise allocations, budget utilization metrics, and automated overspending alerts.
   - Deterministic client-side validation preventing invalid calculations or negative balances.

3. **Chronological Event Timeline**:
   - Milestone tracking, vendor booking deadlines, invitation milestones, and event-day execution schedules.
   - Task dependency tracking with interactive status toggles.

4. **Vendor Management Workspace**:
   - Vendor profiles, categories (Venue, Catering, Decor, Photography, Entertainment, Transportation, Accommodation, Miscellaneous).
   - Quotation comparisons, booking status workflows (Inquired, Quoted, Booked, Paid), and assignment logs.

5. **AI Design Studio**:
   - Dynamic theme concepts, color palettes with hex values, lighting blueprints, stage arrangements, and invitation concepts.

6. **Guest Management**:
   - RSVP tracking (Confirmed, Pending, Declined), dietary requirements, party sizes, and seating group summaries.

7. **Planora AI Interactive Assistant**:
   - Conversational planning assistant powered by **Google Gemini 2.5 Flash**.
   - Speech-to-Text (STT) voice dictation & Text-to-Speech (TTS) audio briefings.
   - High-Thinking mode for multi-stage reasoning and budget optimization.
   - Automated proposal generation with single-tap diff previews and live event updates.

8. **Dynamic Theme Engine**:
   - Instant toggle between **Dark Mode** and **Light Mode** using Material Design 3 dynamic color tokens.

---

## 💻 Running on Your PC (Desktop / Laptop)

You can clone, download, and run **PLANORA AI** locally on **Windows, macOS, or Linux** using Android Studio.

### 📋 Prerequisites

- **Android Studio**: Android Studio Koala (2024.1.2+), Ladybug (2024.2.1+), or newer.
- **Java Development Kit (JDK)**: JDK 17 or JDK 21 (bundled with modern Android Studio).
- **Android SDK**: API Level 35 (compileSdk 35, targetSdk 35, minSdk 26).
- **Git** (optional, for repository management).

---

### 🚀 Step 1: Download or Export the Project

#### Option A: Export Directly to GitHub from AI Studio
1. In the **Google AI Studio** interface, look at the top-right header or project settings menu.
2. Click **Export** ➔ **Push to GitHub** (or connect your GitHub account).
3. AI Studio will automatically create a new GitHub repository under your account and push all files.
4. Clone the repository on your PC:
   ```bash
   git clone https://github.com/<your-username>/planora-ai.git
   cd planora-ai
   ```

#### Option B: Download as ZIP
1. In Google AI Studio, click the **Settings / Menu** icon ➔ **Export Project as ZIP**.
2. Extract the downloaded ZIP file into a folder on your PC (e.g., `C:\Projects\planora-ai` or `~/Projects/planora-ai`).

---

### 🛠️ Step 2: Open in Android Studio

1. Launch **Android Studio**.
2. Click **Open** (or **File ➔ Open...**).
3. Navigate to the extracted `planora-ai` folder and select it.
4. Android Studio will open the project and automatically trigger Gradle Sync.
5. Wait for the initial Gradle sync and dependency download to complete.

---

### 🔑 Step 3: Configure Gemini API Key

Planora AI connects to the **Google Gemini API** for real-time generative event planning.

1. Create a file named `.env` in the root directory of the project (next to `settings.gradle.kts`):
   ```env
   GEMINI_API_KEY=AIzaSy...your_gemini_api_key_here
   ```
2. Get your free API key from [Google AI Studio](https://aistudio.google.com/apikey).

> 💡 **Offline Fallback**: If no API key is provided, Planora AI automatically falls back to its deterministic mathematical planning engine, so you can test all features and workflows even without network access!

---

### 📱 Step 4: Run the App on an Emulator or Device

1. **Setup an Android Virtual Device (AVD)**:
   - In Android Studio, open **Device Manager** (right sidebar or `Tools ➔ Device Manager`).
   - Click **Create Device** (e.g., **Pixel 8** or **Pixel 7**).
   - Select **System Image**: Android 14 (`API 34`) or Android 15 (`API 35`).
   - Click **Finish** and start the virtual device.
   *(Or connect your physical Android phone via USB and enable **Developer Options ➔ USB Debugging**).*

2. **Run the App**:
   - Select `app` in the run configuration dropdown.
   - Click the green **Run** button (▶) or press `Shift + F10` (Windows/Linux) or `Control + R` (macOS).
   - The app will build and install on your emulator/device in seconds.

---

### 🖥️ Step 5: Building from the Command Line (Terminal)

You can also build and test the project directly from your PC terminal:

#### On Windows:
```cmd
# Build debug APK
gradlew.bat assembleDebug

# Run all unit and Robolectric tests
gradlew.bat testDebugUnitTest
```

#### On macOS / Linux:
```bash
# Make wrapper executable
chmod +x gradlew

# Build debug APK
./gradlew assembleDebug

# Run all unit and Robolectric tests
./gradlew testDebugUnitTest
```

The compiled APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

---

### 📦 Step 6: Create or Push to a Git Repository

If you downloaded the project as a ZIP and want to push it to a new GitHub repository manually:

```bash
# Initialize git repository
git init

# Add all files
git add .

# Initial commit
git commit -m "Initial commit: PLANORA AI Event Planning SaaS"

# Link to your GitHub repository
git remote add origin https://github.com/<your-username>/planora-ai.git

# Push to main branch
git branch -M main
git push -u origin main
```

*(Note: Sensitive keys, `.env`, `local.properties`, and build artifacts are pre-configured in `.gitignore` to protect your secrets).*

---

## 🏛️ Project Architecture

```
planora-ai/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/
│   │   │   │   ├── ai/
│   │   │   │   │   ├── GeminiEventPlanner.kt    # Official Gemini SDK integration & structured schemas
│   │   │   │   │   └── AudioSpeechHelper.kt     # Speech-to-Text & Text-to-Speech engine
│   │   │   │   ├── model/
│   │   │   │   │   └── EventModels.kt           # Domain models: Event, Budget, Vendor, Guest, Tasks
│   │   │   │   ├── ui/
│   │   │   │   │   ├── components/              # TopHeaderBar, BottomNavBar, CopilotModalBottomSheet
│   │   │   │   │   ├── screens/                 # Dashboard, Architect, Budget, Timeline, Vendors, Design, Guests
│   │   │   │   │   └── theme/                   # Material 3 colors, dark/light themes, typography
│   │   │   │   ├── util/
│   │   │   │   │   └── CurrencyUtils.kt         # INR Lakh/Crore calculations and budget safety
│   │   │   │   ├── viewmodel/
│   │   │   │   │   └── EventViewModel.kt        # StateFlow MVVM reactive management
│   │   │   │   └── MainActivity.kt              # Root activity, Scaffold, edge-to-edge
│   │   │   └── res/
│   │   │       ├── drawable/                    # Vectors (ic_ai_sparkle, ic_planora_logo, launcher)
│   │   │       ├── mipmap-*/                    # Multi-density app launcher icons
│   │   │       └── values/                      # strings.xml, colors, themes
│   │   └── test/                                # JUnit & Robolectric automated unit tests
│   └── build.gradle.kts                         # App module Gradle configuration
├── gradle/
│   ├── libs.versions.toml                       # Centralized Gradle Version Catalog
│   └── wrapper/                                 # Gradle wrapper configurations
├── .env.example                                 # Template for API keys
├── .gitignore                                   # Git ignore rules for Android Studio & secrets
└── README.md                                    # Complete project documentation
```

---

## 🛡️ Tech Stack & Dependencies

- **UI Framework**: Jetpack Compose (Material 3)
- **Language**: Kotlin 2.2.10
- **AI Intelligence**: Google Gemini 2.5 Flash via Generative AI Android SDK
- **Speech & Audio**: Android `SpeechRecognizer` (STT) + `TextToSpeech` (TTS)
- **Build System**: Gradle 9+ with Kotlin DSL & Version Catalog (`libs.versions.toml`)
- **Testing**: JUnit 4, Robolectric 4.16+, AndroidX Test Suite

---

## 🏆 PromptWars Challenge 05

Built with passion for the **Google for Developers × I2S — PromptWars Challenge 05**.
